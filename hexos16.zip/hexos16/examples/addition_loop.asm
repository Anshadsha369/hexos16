; Example: add 2 + 3 and halt. Each instruction is one 16-bit word.
LDI R1, 2       ; 1102
LDI R2, 3       ; 1203
ADD R1, R1, R2  ; 3112, result 0005 in R1
HALT            ; D000
