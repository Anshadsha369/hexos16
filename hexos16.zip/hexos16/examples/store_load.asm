; Add 2 + 3, store at CPU word address 0100 (RAM offset 0000),
; then load the value back and halt.
LDI R1, 2
LDI R2, 3
ADD R3, R1, R2
LDI16 R4, 0x0100
ST R3, R4
LD R5, R4
HALT
