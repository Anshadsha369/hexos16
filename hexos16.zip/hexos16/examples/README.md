# Example expected result

`addition_loop.asm` assembles to the words in `addition_loop.hex`. After four successful steps: PC=`0004`, R1=`0005`, R2=`0003`, Z=0, N=0, C=0, V=0, halted=true. The `.hex` file is a human-readable word listing, not an image loader format.

`store_load.asm` is the kernel/shell end-to-end example. Load `store_load.hex`; after `RUN`, R3 and R5 contain `0005`, and RAM at CPU address `0100` contains `0005`.
