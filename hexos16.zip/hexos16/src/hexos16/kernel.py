"""Minimal software kernel and instruction-limited program runner."""
from pathlib import Path

from .cpu import CPU
from .memory import MemoryBus, RAM, ROM


class KernelError(Exception):
    """Kernel lifecycle, loader, or execution error."""


class Kernel:
    ROM_RESET = 0x0000
    PROGRAM_START = MemoryBus.RAM_START
    PROGRAM_WORDS = MemoryBus.RAM_END - MemoryBus.RAM_START + 1

    def __init__(self, rom=None, ram=None, instruction_limit=10000):
        if not isinstance(instruction_limit, int) or isinstance(instruction_limit, bool) or instruction_limit < 1:
            raise ValueError("instruction_limit must be positive")
        self.rom = rom if rom is not None else ROM()
        self.ram = ram if ram is not None else RAM()
        self.bus = MemoryBus(self.rom, self.ram)
        self.cpu = CPU(memory=self.bus)
        self.instruction_limit = instruction_limit
        self.loaded_words = 0
        self.instruction_count = 0
        self.initialized = False
        self.initialize()

    def initialize(self):
        if len(self.rom._words) != ROM.SIZE or len(self.ram._words) != RAM.SIZE:
            raise KernelError("memory layout validation failed")
        if (self.bus.ROM_START, self.bus.ROM_END, self.bus.RAM_START, self.bus.RAM_END) != (0, 0xFF, 0x100, 0x10FF):
            raise KernelError("unexpected memory map")
        self.cpu.reset()
        self.cpu.pc = self.ROM_RESET
        self.loaded_words = 0
        self.instruction_count = 0
        self.initialized = True
        return "kernel initialized; reset vector 0000; program RAM 0100-10FF"

    def reset(self):
        self.cpu.reset()
        self.cpu.pc = self.ROM_RESET
        self.ram.clear()
        self.loaded_words = 0
        self.instruction_count = 0
        return "machine reset; RAM cleared; PC=0000"

    @staticmethod
    def parse_hex_image(contents):
        if not isinstance(contents, str):
            raise KernelError("program image must be text")
        words = []
        for line_number, raw in enumerate(contents.splitlines(), 1):
            token = raw.split("#", 1)[0].strip()
            if not token:
                continue
            if len(token) != 4 or any(char not in "0123456789abcdefABCDEF" for char in token):
                raise KernelError(f"line {line_number}: expected one four-digit hexadecimal word")
            words.append(int(token, 16))
            if len(words) > Kernel.PROGRAM_WORDS:
                raise KernelError("program exceeds available RAM")
        if not words:
            raise KernelError("program image is empty")
        return words

    @staticmethod
    def _validate_contents(contents):
        if not isinstance(contents, str):
            raise KernelError("program image must be text")
        words = []
        for line_number, raw in enumerate(contents.splitlines(), 1):
            token = raw.split("#", 1)[0].strip()
            if not token:
                continue
            if len(token) != 4 or any(char not in "0123456789abcdefABCDEF" for char in token):
                raise KernelError(f"line {line_number}: expected one four-digit hexadecimal word")
            if len(words) >= Kernel.PROGRAM_WORDS:
                raise KernelError("program exceeds available RAM")
            words.append(int(token, 16))
        if not words:
            raise KernelError("program image is empty")
        return words

    def load_words(self, words):
        values = list(words)
        if not values or len(values) > self.PROGRAM_WORDS:
            raise KernelError("program must contain 1..4000 words")
        if any(not isinstance(word, int) or isinstance(word, bool) or not 0 <= word <= 0xFFFF for word in values):
            raise KernelError("program words must be integers in 0000..FFFF")
        # Validate all content and capacity before modifying simulated memory.
        staged = values[:]
        for offset, word in enumerate(staged):
            self.bus.write(self.PROGRAM_START + offset, word)
        self.loaded_words = len(staged)
        self.cpu.reset()
        self.cpu.pc = self.PROGRAM_START
        return f"loaded {len(staged):04X} word(s) at {self.PROGRAM_START:04X}"

    def load_file(self, filename):
        try:
            path = Path(filename)
            if path.suffix.lower() != ".hex":
                raise KernelError("only .hex machine-word files may be loaded")
            # Bound the read before parsing, including comments/whitespace.
            if path.stat().st_size > self.PROGRAM_WORDS * 16:
                raise KernelError("program file exceeds size limit")
            content = path.read_text(encoding="ascii")
        except KernelError:
            raise
        except (OSError, UnicodeError) as exc:
            raise KernelError(f"cannot read program file: {exc}") from exc
        words = self._validate_contents(content)
        return self.load_words(words)

    def start(self):
        if not self.loaded_words:
            raise KernelError("no program loaded")
        self.cpu.reset()
        self.cpu.pc = self.PROGRAM_START
        return f"program started at PC={self.cpu.pc:04X}"

    def step(self):
        if not self.loaded_words:
            raise KernelError("no program loaded")
        try:
            result = self.cpu.step()
            if result:
                self.instruction_count += 1
        except Exception as exc:
            raise KernelError(f"CPU fault at/after PC={self.cpu.pc:04X}: {type(exc).__name__}: {exc}") from exc
        return result

    def run(self, limit=None):
        if not self.loaded_words:
            raise KernelError("no program loaded")
        max_steps = self.instruction_limit if limit is None else limit
        if not isinstance(max_steps, int) or isinstance(max_steps, bool) or max_steps < 1:
            raise KernelError("instruction limit must be positive")
        steps = 0
        while not self.cpu.halted and self.cpu.error is None and steps < max_steps:
            self.step()
            steps += 1
        if self.cpu.error is not None:
            raise KernelError(f"CPU fault: {type(self.cpu.error).__name__}: {self.cpu.error}")
        if not self.cpu.halted:
            raise KernelError(f"instruction limit {max_steps} reached at PC={self.cpu.pc:04X}")
        return f"halted after {steps:04X} instruction(s); PC={self.cpu.pc:04X}"

    def inspect(self, address, count=1):
        if self.bus.ROM_START <= address <= self.bus.ROM_END:
            return self.rom.inspect(address, count)
        if self.bus.RAM_START <= address <= self.bus.RAM_END:
            return [(f"{address + i:04X}", f"{self.bus.read(address + i):04X}") for i in range(count)]
        raise IndexError(f"unmapped address {address:04X}")
