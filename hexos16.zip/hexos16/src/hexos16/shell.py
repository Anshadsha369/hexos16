"""Restricted interactive command shell; never dispatches host commands."""
import shlex

from .kernel import Kernel, KernelError


class Shell:
    HELP = "HELP REG MEM <address> [count] LOAD <file.hex> RUN STEP RESET EXIT"

    def __init__(self, kernel=None):
        self.kernel = kernel if kernel is not None else Kernel()
        self.running = True

    @staticmethod
    def _number(text):
        try:
            if text.upper().startswith("D:"):
                return int(text[2:], 10)
            return int(text[2:], 16) if text.lower().startswith("0x") else int(text, 16)
        except ValueError as exc:
            raise ValueError(f"invalid number {text!r}; use hexadecimal or D:<decimal>") from exc

    def execute(self, line):
        try:
            args = shlex.split(line)
        except ValueError as exc:
            return f"ERROR: {exc}"
        if not args:
            return ""
        command = args[0].upper()
        try:
            if command == "HELP" and len(args) == 1:
                return self.HELP + "\nNumbers are hexadecimal; prefix decimal values with D: (example D:10)."
            if command == "REG" and len(args) == 1:
                cpu = self.kernel.cpu
                regs = " ".join(f"R{i:X}={value:04X}" for i, value in enumerate(cpu.registers))
                flags = cpu.flags
                return f"{regs}\nPC={cpu.pc:04X} SP={cpu.sp:04X} FLAGS=Z{int(flags.z)}N{int(flags.n)}C{int(flags.c)}V{int(flags.v)}"
            if command == "MEM" and 2 <= len(args) <= 3:
                address = self._number(args[1])
                count = self._number(args[2]) if len(args) == 3 else 1
                if count < 1 or count > 0x100:
                    raise ValueError("count must be 1..0100 words")
                return "\n".join(f"{a}: {v}" for a, v in self.kernel.inspect(address, count))
            if command == "LOAD" and len(args) == 2:
                return self.kernel.load_file(args[1])
            if command == "RUN" and len(args) == 1:
                return self.kernel.run()
            if command == "STEP" and len(args) == 1:
                before = self.kernel.cpu.pc
                self.kernel.step()
                return f"step at {before:04X}; PC={self.kernel.cpu.pc:04X}" + (" HALTED" if self.kernel.cpu.halted else "")
            if command == "RESET" and len(args) == 1:
                return self.kernel.reset()
            if command == "EXIT" and len(args) == 1:
                self.running = False
                return "exit"
            if command in {"HELP", "REG", "MEM", "LOAD", "RUN", "STEP", "RESET", "EXIT"}:
                return f"ERROR: malformed arguments for {command}"
            return f"ERROR: unknown command {command}"
        except (KernelError, ValueError, IndexError, PermissionError) as exc:
            return f"ERROR: {exc}"

    def loop(self, input_fn=input, output_fn=print):
        output_fn(self.kernel.initialize())
        while self.running:
            try:
                line = input_fn("HEXOS16> ")
            except EOFError:
                break
            result = self.execute(line)
            if result:
                output_fn(result)


def main():
    Shell().loop()


if __name__ == "__main__":
    main()
