"""HEXOS-16 simulated word memories and a non-I/O address bus."""

WORD_MAX = 0xFFFF


def _word(value):
    if not isinstance(value, int) or isinstance(value, bool) or not 0 <= value <= WORD_MAX:
        raise ValueError("word value must be an integer in 0000..FFFF")
    return value


class RAM:
    """4,096 host-backed simulated 16-bit words, addresses 0000..0FFF."""
    SIZE = 0x1000

    def __init__(self, initial=None):
        self._words = [0] * self.SIZE
        if initial is not None:
            values = list(initial)
            if len(values) > self.SIZE:
                raise ValueError("RAM initializer exceeds 1000 words")
            for i, value in enumerate(values):
                self._words[i] = _word(value)

    @staticmethod
    def _address(address):
        if not isinstance(address, int) or isinstance(address, bool) or not 0 <= address < RAM.SIZE:
            raise IndexError("RAM address must be in 0000..0FFF")

    def read(self, address):
        self._address(address)
        return self._words[address]

    def write(self, address, value):
        self._address(address)
        self._words[address] = _word(value)

    def clear(self):
        self._words[:] = [0] * self.SIZE

    def inspect(self, start=0, count=16):
        if not isinstance(count, int) or count < 0:
            raise ValueError("count must be a nonnegative integer")
        self._address(start)
        if start + count > self.SIZE:
            raise IndexError("inspection extends past RAM")
        return [(f"{address:04X}", f"{self._words[address]:04X}") for address in range(start, start + count)]


class ROM:
    """256 word read-only image. Short images are zero-filled."""
    SIZE = 0x100

    def __init__(self, image=()):
        values = self._parse_image(image)
        if len(values) > self.SIZE:
            raise ValueError("ROM image exceeds 0100 words")
        self._words = values + [0] * (self.SIZE - len(values))

    @staticmethod
    def _parse_image(image):
        if isinstance(image, str):
            values = []
            for line_number, line in enumerate(image.splitlines(), 1):
                token = line.split("#", 1)[0].strip()
                if not token:
                    continue
                if len(token) != 4 or any(ch not in "0123456789abcdefABCDEF" for ch in token):
                    raise ValueError(f"malformed ROM word on line {line_number}")
                values.append(int(token, 16))
            return values
        try:
            return [_word(value) for value in image]
        except TypeError as exc:
            raise ValueError("ROM image must be four-digit hex lines or an iterable of words") from exc

    @staticmethod
    def _address(address):
        if not isinstance(address, int) or isinstance(address, bool) or not 0 <= address < ROM.SIZE:
            raise IndexError("ROM address must be in 0000..00FF")

    def read(self, address):
        self._address(address)
        return self._words[address]

    def write(self, address, value):
        raise PermissionError("ROM is read-only")

    def inspect(self, start=0, count=16):
        if not isinstance(count, int) or count < 0:
            raise ValueError("count must be a nonnegative integer")
        self._address(start)
        if start + count > self.SIZE:
            raise IndexError("inspection extends past ROM")
        return [(f"{address:04X}", f"{self._words[address]:04X}") for address in range(start, start + count)]


class MemoryBus:
    """Word-addressed map: ROM 0000..00FF, RAM 0100..10FF; no I/O mapping."""
    ROM_START, ROM_END = 0x0000, 0x00FF
    RAM_START, RAM_END = 0x0100, 0x10FF

    def __init__(self, rom=None, ram=None):
        self.rom = rom if rom is not None else ROM()
        self.ram = ram if ram is not None else RAM()

    def read(self, address):
        if self.ROM_START <= address <= self.ROM_END:
            return self.rom.read(address)
        if self.RAM_START <= address <= self.RAM_END:
            return self.ram.read(address - self.RAM_START)
        raise IndexError(f"unmapped memory address {address:04X}")

    def write(self, address, value):
        if self.RAM_START <= address <= self.RAM_END:
            self.ram.write(address - self.RAM_START, value)
            return
        if self.ROM_START <= address <= self.ROM_END:
            raise PermissionError("cannot write to ROM address")
        raise IndexError(f"unmapped memory address {address:04X}")
