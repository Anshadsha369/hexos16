"""Assembler for the one-word HEXOS-16 ISA."""
import re


class AssemblyError(ValueError):
    """Source-level assembler diagnostic."""


OPS = {"NOP": 0x0, "LDI": 0x1, "LDI16": 0x10, "MOV": 0x2, "ADD": 0x3, "SUB": 0x4,
       "AND": 0x5, "OR": 0x6, "XOR": 0x7, "CMP": 0x8, "BR": 0x9,
       "BZ": 0xA, "BNZ": 0xB, "BC": 0xC, "HALT": 0xD, "LD": 0xE, "ST": 0xF}


def _number(token, line):
    try:
        if token.lower().startswith("0x"):
            return int(token[2:], 16)
        return int(token, 10)
    except ValueError as exc:
        raise AssemblyError(f"line {line}: invalid numeric literal {token!r}") from exc


def _reg(token, line):
    match = re.fullmatch(r"R([0-9A-F])", token.strip().upper())
    if not match:
        raise AssemblyError(f"line {line}: invalid register {token!r}; expected R0..RF")
    return int(match.group(1), 16)


def assemble(source):
    """Return list of 16-bit words; labels are case-insensitive."""
    parsed, labels, pc = [], {}, 0
    for line_no, raw in enumerate(source.splitlines(), 1):
        line = raw.split(";", 1)[0].split("#", 1)[0].strip()
        if not line:
            continue
        if ":" in line:
            label, line = line.split(":", 1)
            label = label.strip().upper()
            if not re.fullmatch(r"[A-Z_][A-Z0-9_]*", label):
                raise AssemblyError(f"line {line_no}: invalid label {label!r}")
            if label in labels:
                raise AssemblyError(f"line {line_no}: duplicate label {label}")
            labels[label] = pc
            line = line.strip()
            if not line:
                continue
        pieces = line.split(None, 1)
        mnemonic = pieces[0].upper()
        if mnemonic not in OPS:
            raise AssemblyError(f"line {line_no}: unsupported instruction {mnemonic!r}")
        operands = [] if len(pieces) == 1 else [p.strip() for p in pieces[1].split(",")]
        if any(not p for p in operands):
            raise AssemblyError(f"line {line_no}: malformed operand list")
        parsed.append((line_no, pc, mnemonic, operands))
        pc += 2 if mnemonic == "LDI16" else 1

    words = []
    for line, addr, mnemonic, args in parsed:
        op = OPS[mnemonic]
        expected = {"NOP": 0, "HALT": 0, "LDI": 2, "LDI16": 2, "MOV": 2, "ADD": 3, "SUB": 3,
                    "AND": 3, "OR": 3, "XOR": 3, "CMP": 2, "BR": 1, "BZ": 1,
                    "BNZ": 1, "BC": 1, "LD": 2, "ST": 2}[mnemonic]
        if len(args) != expected:
            raise AssemblyError(f"line {line}: {mnemonic} expects {expected} operand(s), got {len(args)}")
        if mnemonic in ("NOP", "HALT"):
            word = op << 12
        elif mnemonic == "LDI":
            d, value = _reg(args[0], line), _number(args[1], line)
            if not 0 <= value <= 0xF: raise AssemblyError(f"line {line}: LDI immediate must be 0..15")
            word = (op << 12) | (d << 8) | value
        elif mnemonic == "LDI16":
            d, value = _reg(args[0], line), _number(args[1], line)
            if not 0 <= value <= 0xFFFF: raise AssemblyError(f"line {line}: LDI16 immediate must be 0..65535")
            words.extend([0x0010 | (d << 8), value])
            continue
        elif mnemonic == "MOV":
            d, a = _reg(args[0], line), _reg(args[1], line)
            word = (op << 12) | (d << 8) | (a << 4)
        elif mnemonic in ("ADD", "SUB", "AND", "OR", "XOR"):
            d, a, b = (_reg(arg, line) for arg in args)
            word = (op << 12) | (d << 8) | (a << 4) | b
        elif mnemonic == "CMP":
            a, b = (_reg(arg, line) for arg in args)
            word = (op << 12) | (a << 4) | b
        elif mnemonic in ("BR", "BZ", "BNZ", "BC"):
            target = args[0].upper()
            if target in labels:
                disp = labels[target] - (addr + 1)
            else:
                disp = _number(args[0], line)
            if not -128 <= disp <= 127: raise AssemblyError(f"line {line}: branch displacement out of range (-128..127)")
            word = (op << 12) | (disp & 0xFF)
        elif mnemonic in ("LD", "ST"):
            d, a = (_reg(arg, line) for arg in args)
            word = (op << 12) | (d << 8) | (a << 4)
        words.append(word)
    return words


def format_hex(words):
    """Format machine words as deterministic uppercase .hex text."""
    values = list(words)
    if any(not isinstance(w, int) or isinstance(w, bool) or not 0 <= w <= 0xFFFF for w in values):
        raise ValueError("words must be integers in 0000..FFFF")
    return "".join(f"{word:04X}\n" for word in values)
