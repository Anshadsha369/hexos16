"""Small deterministic HEXOS-16 milestone-1 CPU."""
from dataclasses import dataclass

MASK = 0xFFFF


class InvalidInstruction(Exception):
    """An unsupported opcode or malformed instruction word was fetched."""


@dataclass
class Flags:
    z: bool = False
    n: bool = False
    c: bool = False
    v: bool = False


class CPU:
    def __init__(self, program=None, memory=None):
        # Legacy flat mode remains available. A supplied memory object must
        # implement read(address) and write(address, value).
        self.memory = memory if memory is not None else [0] * 0x10000
        self.registers = [0] * 16
        self.pc = 0
        self.sp = 0
        self.flags = Flags()
        self.halted = False
        self.error = None
        if program is not None:
            self.load_program(program)

    def reset(self):
        self.registers[:] = [0] * 16
        self.pc = self.sp = 0
        self.flags = Flags()
        self.halted = False
        self.error = None

    def load_program(self, words, address=0):
        words = list(words)
        if not 0 <= address <= MASK or address + len(words) > MASK + 1:
            raise ValueError("program does not fit 16-bit address space")
        if any(not isinstance(w, int) or not 0 <= w <= MASK for w in words):
            raise ValueError("program words must be integers in 0000..FFFF")
        if isinstance(self.memory, list):
            self.memory[address:address + len(words)] = words
        else:
            for offset, word in enumerate(words):
                self.memory.write(address + offset, word)
        self.pc = address
        self.halted = False
        self.error = None

    def _logic_flags(self, result):
        self.flags.z = result == 0
        self.flags.n = bool(result & 0x8000)
        self.flags.c = self.flags.v = False

    def _sub_flags(self, a, b):
        result = (a - b) & MASK
        self.flags.z = result == 0
        self.flags.n = bool(result & 0x8000)
        self.flags.c = a >= b
        self.flags.v = bool(((a ^ b) & (a ^ result) & 0x8000))
        return result

    def step(self):
        if self.halted or self.error is not None:
            return False
        try:
            word = self.memory[self.pc] if isinstance(self.memory, list) else self.memory.read(self.pc)
        except Exception as exc:
            self.error = exc
            self.halted = True
            raise
        self.pc = (self.pc + 1) & MASK
        op, d, a, b = (word >> 12) & 0xF, (word >> 8) & 0xF, (word >> 4) & 0xF, word & 0xF
        try:
            if op == 0:
                if word == 0:
                    pass
                elif (word & 0xF0F0) == 0x0010:
                    # LDI16 carries its literal in the following word.
                    ext_address = self.pc
                    extension = self.memory[ext_address] if isinstance(self.memory, list) else self.memory.read(ext_address)
                    self.pc = (self.pc + 1) & MASK
                    d = (word >> 8) & 0xF
                    self.registers[d] = extension
                    self._logic_flags(extension)
                else:
                    raise InvalidInstruction(f"invalid opcode-0 encoding {word:04X}")
            elif op == 1:
                result = word & 0xF
                self.registers[d] = result
                self._logic_flags(result)
            elif op == 2:
                if b != 0: raise InvalidInstruction(f"invalid MOV encoding {word:04X}")
                result = self.registers[a]
                self.registers[d] = result
                self._logic_flags(result)
            elif 3 <= op <= 7:
                x, y = self.registers[a], self.registers[b]
                if op == 3:
                    full = x + y; result = full & MASK
                    self.flags.c = full > MASK
                    self.flags.v = bool((~(x ^ y) & (x ^ result) & 0x8000))
                    self.flags.z = result == 0; self.flags.n = bool(result & 0x8000)
                elif op == 4: result = self._sub_flags(x, y)
                else:
                    result = {5: x & y, 6: x | y, 7: x ^ y}[op]
                    self._logic_flags(result)
                self.registers[d] = result
            elif op == 8:
                if d != 0: raise InvalidInstruction(f"invalid CMP encoding {word:04X}")
                self._sub_flags(self.registers[a], self.registers[b])
            elif 9 <= op <= 12:
                if d != 0: raise InvalidInstruction(f"invalid branch encoding {word:04X}")
                take = op == 9 or (op == 10 and self.flags.z) or (op == 11 and not self.flags.z) or (op == 12 and self.flags.c)
                if take:
                    disp = word & 0xFF
                    if disp & 0x80: disp -= 0x100
                    self.pc = (self.pc + disp) & MASK
            elif op == 13:
                if word != 0xD000: raise InvalidInstruction(f"invalid HALT encoding {word:04X}")
                self.halted = True
            elif op in (14, 15):
                if b != 0: raise InvalidInstruction(f"invalid memory encoding {word:04X}")
                address = self.registers[a]
                if op == 14:
                    result = self.memory[address] if isinstance(self.memory, list) else self.memory.read(address)
                    self.registers[d] = result
                    self._logic_flags(result)
                else:
                    value = self.registers[d]
                    if isinstance(self.memory, list):
                        self.memory[address] = value
                    else:
                        self.memory.write(address, value)
            else:
                raise InvalidInstruction(f"invalid opcode {op:X} in {word:04X}")
            return True
        except Exception as exc:
            self.error = exc
            self.halted = True
            raise
