"""Shared visual style constants and font helpers for the HEXOS-16 GUI."""

from __future__ import annotations

from PySide6.QtGui import QFont

PALETTE = {
    "background":   "#0D1117",
    "surface":      "#161B22",
    "surface2":     "#1C2128",
    "border":       "#30363D",
    "label":        "#8B949E",
    "text":         "#C9D1D9",
    "hex_value":    "#79C0FF",
    "accent":       "#388BFD",
    "accent_dim":   "#1C3050",
    "rom_bg":       "#1A1A2E",
    "rom_fg":       "#BB8FCE",
    "ram_bg":       "#162032",
    "ram_fg":       "#79C0FF",
    "flag_set":     "#56D364",
    "flag_set_bg":  "#122318",
    "flag_clear":   "#484F58",
    "status_ready": "#56D364",
    "status_halted":"#E3B341",
    "error":        "#F85149",
    "console_bg":   "#010409",
    "console_text": "#7EE787",
    "console_cmd":  "#C9D1D9",
    "branding":     "#388BFD",
    "separator":    "#21262D",
}


def mono_font(size: int = 12) -> QFont:
    """Return a monospace font at the given point size."""
    font = QFont("Consolas")
    font.setStyleHint(QFont.Monospace)
    font.setPointSize(size)
    return font


def label_font(size: int = 10, bold: bool = False) -> QFont:
    font = QFont("Segoe UI")
    font.setPointSize(size)
    font.setBold(bold)
    return font


def title_font(size: int = 16) -> QFont:
    font = QFont("Segoe UI")
    font.setPointSize(size)
    font.setBold(True)
    return font


APP_STYLESHEET = f"""
QWidget {{
    background-color: {PALETTE['background']};
    color: {PALETTE['text']};
    font-family: "Segoe UI";
}}
QScrollArea {{
    border: none;
    background: {PALETTE['background']};
}}
QScrollBar:vertical {{
    background: {PALETTE['surface']};
    width: 8px;
    border-radius: 4px;
}}
QScrollBar::handle:vertical {{
    background: {PALETTE['border']};
    border-radius: 4px;
    min-height: 20px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0px;
}}
QScrollBar:horizontal {{
    background: {PALETTE['surface']};
    height: 8px;
    border-radius: 4px;
}}
QScrollBar::handle:horizontal {{
    background: {PALETTE['border']};
    border-radius: 4px;
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    width: 0px;
}}
QTabWidget::pane {{
    border: 1px solid {PALETTE['border']};
    background: {PALETTE['surface']};
    border-radius: 4px;
}}
QTabBar::tab {{
    background: {PALETTE['surface2']};
    color: {PALETTE['label']};
    padding: 6px 16px;
    border: 1px solid {PALETTE['border']};
    border-bottom: none;
    border-radius: 4px 4px 0 0;
}}
QTabBar::tab:selected {{
    background: {PALETTE['surface']};
    color: {PALETTE['text']};
    border-bottom-color: {PALETTE['surface']};
}}
QTabBar::tab:hover {{
    color: {PALETTE['text']};
}}
QPushButton {{
    background: {PALETTE['surface2']};
    color: {PALETTE['text']};
    border: 1px solid {PALETTE['border']};
    border-radius: 5px;
    padding: 5px 14px;
    min-width: 70px;
}}
QPushButton:hover {{
    background: {PALETTE['accent_dim']};
    border-color: {PALETTE['accent']};
    color: {PALETTE['text']};
}}
QPushButton:pressed {{
    background: {PALETTE['accent']};
    color: white;
}}
QPushButton:disabled {{
    color: {PALETTE['border']};
    border-color: {PALETTE['separator']};
}}
QLineEdit {{
    background: {PALETTE['surface']};
    color: {PALETTE['text']};
    border: 1px solid {PALETTE['border']};
    border-radius: 4px;
    padding: 4px 8px;
    selection-background-color: {PALETTE['accent']};
}}
QLineEdit:focus {{
    border-color: {PALETTE['accent']};
}}
QTextEdit, QPlainTextEdit {{
    background: {PALETTE['surface']};
    color: {PALETTE['text']};
    border: 1px solid {PALETTE['border']};
    border-radius: 4px;
    selection-background-color: {PALETTE['accent_dim']};
}}
QSplitter::handle {{
    background: {PALETTE['separator']};
}}
QLabel {{
    background: transparent;
    color: {PALETTE['text']};
}}
QSpinBox, QComboBox {{
    background: {PALETTE['surface']};
    color: {PALETTE['text']};
    border: 1px solid {PALETTE['border']};
    border-radius: 4px;
    padding: 3px 6px;
}}
QSpinBox:focus, QComboBox:focus {{
    border-color: {PALETTE['accent']};
}}
QComboBox::drop-down {{
    border: none;
    width: 18px;
}}
QToolTip {{
    background: {PALETTE['surface2']};
    color: {PALETTE['text']};
    border: 1px solid {PALETTE['border']};
    padding: 4px;
}}
QMessageBox {{
    background: {PALETTE['surface']};
}}
QMenuBar {{
    background: {PALETTE['surface']};
    color: {PALETTE['text']};
    border-bottom: 1px solid {PALETTE['border']};
}}
QMenuBar::item:selected {{
    background: {PALETTE['accent_dim']};
}}
QMenu {{
    background: {PALETTE['surface2']};
    color: {PALETTE['text']};
    border: 1px solid {PALETTE['border']};
}}
QMenu::item:selected {{
    background: {PALETTE['accent_dim']};
}}
QStatusBar {{
    background: {PALETTE['surface']};
    color: {PALETTE['label']};
    border-top: 1px solid {PALETTE['border']};
}}
"""
