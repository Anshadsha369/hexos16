"""Assembly editor widget — source editing, assembling, and .hex generation."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional, Callable

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont, QTextCursor, QTextCharFormat, QColor, QSyntaxHighlighter
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QPlainTextEdit, QTextEdit, QSplitter,
    QGroupBox, QMessageBox, QSizePolicy,
)

from hexos16.assembler import assemble, format_hex, AssemblyError
from .style import PALETTE, mono_font, label_font

# ---------------------------------------------------------------------------
# Syntax highlighter for HEXOS-16 assembly
# ---------------------------------------------------------------------------

class _AsmHighlighter(QSyntaxHighlighter):
    """Minimal syntax highlighter: mnemonics, registers, labels, comments."""

    MNEMONICS = {
        "NOP", "LDI", "LDI16", "MOV", "ADD", "SUB", "AND", "OR", "XOR",
        "CMP", "BR", "BZ", "BNZ", "BC", "HALT", "LD", "ST",
    }

    def __init__(self, document) -> None:
        super().__init__(document)
        self._fmt_mnemonic = self._fmt(PALETTE["accent"])
        self._fmt_register = self._fmt(PALETTE["hex_value"])
        self._fmt_label = self._fmt(PALETTE["status_halted"])
        self._fmt_comment = self._fmt(PALETTE["label"])
        self._fmt_number = self._fmt(PALETTE["status_ready"])

    @staticmethod
    def _fmt(color: str) -> QTextCharFormat:
        f = QTextCharFormat()
        f.setForeground(QColor(color))
        return f

    def highlightBlock(self, text: str) -> None:
        import re
        # Strip comment
        comment_pos = -1
        for marker in (";", "#"):
            p = text.find(marker)
            if p != -1 and (comment_pos == -1 or p < comment_pos):
                comment_pos = p
        if comment_pos != -1:
            self.setFormat(comment_pos, len(text) - comment_pos, self._fmt_comment)
            text = text[:comment_pos]

        # Label
        label_match = re.match(r"^(\s*)([A-Za-z_][A-Za-z0-9_]*)(\s*):", text)
        if label_match:
            start = label_match.start(2)
            length = len(label_match.group(2))
            self.setFormat(start, length, self._fmt_label)

        # Mnemonics
        for m in re.finditer(r"\b([A-Za-z][A-Za-z0-9]*)\b", text):
            word = m.group(1).upper()
            if word in self.MNEMONICS:
                self.setFormat(m.start(1), len(m.group(1)), self._fmt_mnemonic)

        # Registers R0..RF
        for m in re.finditer(r"\bR([0-9A-Fa-f])\b", text):
            self.setFormat(m.start(), len(m.group()), self._fmt_register)

        # Hex literals
        for m in re.finditer(r"\b0x[0-9A-Fa-f]+\b", text):
            self.setFormat(m.start(), len(m.group()), self._fmt_number)

        # Decimal literals
        for m in re.finditer(r"(?<![0-9A-Fa-fx])\b\d+\b", text):
            self.setFormat(m.start(), len(m.group()), self._fmt_number)


# ---------------------------------------------------------------------------
# Line-number gutter
# ---------------------------------------------------------------------------

class _LineNumberArea(QWidget):
    def __init__(self, editor) -> None:
        super().__init__(editor)
        self._editor = editor

    def sizeHint(self):
        from PySide6.QtCore import QSize
        return QSize(self._editor._line_number_width(), 0)

    def paintEvent(self, event):
        self._editor._paint_line_numbers(event)


class _CodeEditor(QPlainTextEdit):
    """Plain-text editor with a line-number gutter."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._line_area = _LineNumberArea(self)
        self.blockCountChanged.connect(self._update_gutter_width)
        self.updateRequest.connect(self._update_gutter)
        self._update_gutter_width()

    def _line_number_width(self) -> int:
        digits = max(3, len(str(self.blockCount())))
        return 6 + self.fontMetrics().horizontalAdvance("9") * digits

    def _update_gutter_width(self) -> None:
        self.setViewportMargins(self._line_number_width(), 0, 0, 0)

    def _update_gutter(self, rect, dy) -> None:
        if dy:
            self._line_area.scroll(0, dy)
        else:
            self._line_area.update(0, rect.y(), self._line_area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self._update_gutter_width()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        cr = self.contentsRect()
        self._line_area.setGeometry(cr.left(), cr.top(), self._line_number_width(), cr.height())

    def _paint_line_numbers(self, event) -> None:
        from PySide6.QtGui import QPainter
        painter = QPainter(self._line_area)
        painter.fillRect(event.rect(), QColor(PALETTE["surface2"]))
        block = self.firstVisibleBlock()
        block_num = block.blockNumber()
        top = int(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + int(self.blockBoundingRect(block).height())
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                painter.setPen(QColor(PALETTE["label"]))
                painter.setFont(self.font())
                painter.drawText(0, top, self._line_area.width() - 3,
                                 self.fontMetrics().height(),
                                 Qt.AlignRight, str(block_num + 1))
            block = block.next()
            top = bottom
            bottom = top + int(self.blockBoundingRect(block).height())
            block_num += 1


# ---------------------------------------------------------------------------
# Editor view
# ---------------------------------------------------------------------------

EXAMPLE_PROGRAMS = {
    "Fibonacci (R0=fib(8))": """; Compute the 8th Fibonacci number in R0.
; F(0)=0 F(1)=1 F(2)=1 F(3)=2 ... F(8)=21
LDI R0, 0      ; a = 0
LDI R1, 1      ; b = 1
LDI R2, 0      ; counter = 0
LDI R3, 8      ; limit  = 8
loop:
  CMP R2, R3
  BZ  done
  ADD R4, R0, R1  ; tmp = a + b
  MOV R0, R1      ; a = b
  MOV R1, R4      ; b = tmp
  LDI R5, 1
  ADD R2, R2, R5  ; counter++
  BR  loop
done:
HALT
""",
    "Addition (2 + 3)": """; Add 2 + 3 and store the result in RAM at 0100.
LDI R1, 2
LDI R2, 3
ADD R3, R1, R2
LDI16 R4, 0x0100
ST R3, R4
LD R5, R4
HALT
""",
    "Countdown loop": """; Count down from 5 to 0 in R0.
LDI R0, 5       ; counter
LDI R1, 1       ; decrement
loop:
  CMP R0, R1    ; compare counter with 1
  BZ  done      ; branch if counter == 1 (avoid underflow)
  SUB R0, R0, R1
  BR  loop
done:
HALT
""",
    "Conditional branch": """; Branch on zero: R1 = 0 should take the BZ.
LDI R1, 0
LDI R2, 5
CMP R1, R2   ; Z=0 because 0 != 5
BNZ not_equal
LDI R3, 0    ; skipped
BR  done
not_equal:
LDI R3, 1    ; R3 = 1 if not equal
done:
HALT
""",
    "Instruction limit demo": """; Infinite loop — demonstrates instruction limit.
LDI R0, 1
loop:
  ADD R0, R0, R0
  BR  loop
""",
}


class EditorView(QWidget):
    """Multi-line assembly editor with assembler integration."""

    # Signals
    load_words_requested = Signal(list)   # list of int words
    status_message = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._current_file: Optional[Path] = None
        self._modified = False
        self._last_words: Optional[list] = None
        self._build_ui()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)

        # ── Toolbar ───────────────────────────────────────────────────
        toolbar = QHBoxLayout()
        toolbar.setSpacing(6)

        self._file_label = QLabel("unsaved")
        self._file_label.setFont(label_font(9))
        self._file_label.setStyleSheet(f"color: {PALETTE['label']};")

        new_btn  = QPushButton("New")
        open_btn = QPushButton("Open…")
        save_btn = QPushButton("Save")
        saveas_btn = QPushButton("Save As…")
        asm_btn  = QPushButton("▶  Assemble")
        asm_btn.setStyleSheet(
            f"background: {PALETTE['accent']}; color: white; font-weight: bold; "
            f"border: none; border-radius: 5px; padding: 5px 16px;"
        )
        load_btn = QPushButton("Load into VM")
        load_btn.setToolTip("Assemble and load the machine code into RAM")

        from PySide6.QtWidgets import QComboBox
        self._example_combo = QComboBox()
        self._example_combo.addItem("Load example…")
        for name in EXAMPLE_PROGRAMS:
            self._example_combo.addItem(name)
        self._example_combo.currentIndexChanged.connect(self._load_example)

        new_btn.clicked.connect(self._new_file)
        open_btn.clicked.connect(self._open_file)
        save_btn.clicked.connect(self._save_file)
        saveas_btn.clicked.connect(self._save_as_file)
        asm_btn.clicked.connect(self._assemble)
        load_btn.clicked.connect(self._assemble_and_load)

        toolbar.addWidget(self._file_label)
        toolbar.addStretch()
        toolbar.addWidget(self._example_combo)
        toolbar.addSpacing(8)
        toolbar.addWidget(new_btn)
        toolbar.addWidget(open_btn)
        toolbar.addWidget(save_btn)
        toolbar.addWidget(saveas_btn)
        toolbar.addSpacing(8)
        toolbar.addWidget(asm_btn)
        toolbar.addWidget(load_btn)
        root.addLayout(toolbar)

        # ── Editor / output splitter ──────────────────────────────────
        splitter = QSplitter(Qt.Vertical)

        self._editor = _CodeEditor()
        self._editor.setFont(mono_font(11))
        self._editor.setStyleSheet(
            f"background: {PALETTE['surface']}; color: {PALETTE['text']}; "
            f"border: 1px solid {PALETTE['border']}; border-radius: 4px;"
        )
        self._editor.setPlaceholderText("Enter HEXOS-16 assembly here…")
        self._editor.textChanged.connect(self._on_text_changed)
        self._highlighter = _AsmHighlighter(self._editor.document())
        splitter.addWidget(self._editor)

        output_box = QGroupBox("Assembler output / machine code")
        output_box.setStyleSheet(
            f"QGroupBox {{ color: {PALETTE['label']}; border: 1px solid {PALETTE['border']}; "
            f"border-radius: 4px; margin-top: 8px; background: {PALETTE['surface']}; }}"
            f"QGroupBox::title {{ subcontrol-origin: margin; left: 8px; "
            f"color: {PALETTE['label']}; background: {PALETTE['background']}; padding: 0 4px; }}"
        )
        out_lay = QVBoxLayout(output_box)
        out_lay.setContentsMargins(6, 4, 6, 4)

        out_btn_row = QHBoxLayout()
        copy_hex_btn = QPushButton("Copy hex")
        save_hex_btn = QPushButton("Save .hex…")
        copy_hex_btn.clicked.connect(self._copy_hex)
        save_hex_btn.clicked.connect(self._save_hex)
        out_btn_row.addStretch()
        out_btn_row.addWidget(copy_hex_btn)
        out_btn_row.addWidget(save_hex_btn)
        out_lay.addLayout(out_btn_row)

        self._output = QPlainTextEdit()
        self._output.setReadOnly(True)
        self._output.setFont(mono_font(10))
        self._output.setStyleSheet(
            f"background: {PALETTE['console_bg']}; color: {PALETTE['console_text']}; "
            f"border: none;"
        )
        out_lay.addWidget(self._output)

        self._error_output = QLabel("")
        self._error_output.setFont(label_font())
        self._error_output.setWordWrap(True)
        self._error_output.setStyleSheet(f"color: {PALETTE['error']}; background: transparent;")
        out_lay.addWidget(self._error_output)

        splitter.addWidget(output_box)
        splitter.setSizes([350, 200])
        root.addWidget(splitter, stretch=1)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _on_text_changed(self) -> None:
        self._modified = True
        self._update_title()

    def _update_title(self) -> None:
        name = self._current_file.name if self._current_file else "unsaved"
        marker = " •" if self._modified else ""
        self._file_label.setText(f"{name}{marker}")

    def _confirm_discard(self) -> bool:
        if not self._modified:
            return True
        result = QMessageBox.question(
            self, "Unsaved changes",
            "The editor has unsaved changes. Discard them?",
            QMessageBox.Discard | QMessageBox.Cancel,
        )
        return result == QMessageBox.Discard

    def _new_file(self) -> None:
        if not self._confirm_discard():
            return
        self._editor.clear()
        self._current_file = None
        self._modified = False
        self._update_title()

    def _open_file(self) -> None:
        if not self._confirm_discard():
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Open assembly file", "",
            "Assembly files (*.asm);;All files (*.*)"
        )
        if not path:
            return
        try:
            text = Path(path).read_text(encoding="utf-8")
        except OSError as exc:
            QMessageBox.critical(self, "Open failed", str(exc))
            return
        self._editor.setPlainText(text)
        self._current_file = Path(path)
        self._modified = False
        self._update_title()

    def _save_file(self) -> None:
        if self._current_file is None:
            self._save_as_file()
            return
        self._write_file(self._current_file)

    def _save_as_file(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save assembly file", "",
            "Assembly files (*.asm);;All files (*.*)"
        )
        if not path:
            return
        self._current_file = Path(path)
        self._write_file(self._current_file)

    def _write_file(self, path: Path) -> None:
        try:
            path.write_text(self._editor.toPlainText(), encoding="utf-8")
            self._modified = False
            self._update_title()
            self.status_message.emit(f"Saved {path.name}")
        except OSError as exc:
            QMessageBox.critical(self, "Save failed", str(exc))

    def _load_example(self, index: int) -> None:
        if index == 0:
            return
        name = self._example_combo.currentText()
        if not self._confirm_discard():
            self._example_combo.setCurrentIndex(0)
            return
        src = EXAMPLE_PROGRAMS.get(name, "")
        self._editor.setPlainText(src)
        self._current_file = None
        self._modified = False
        self._update_title()
        self._example_combo.setCurrentIndex(0)

    def _assemble(self) -> bool:
        """Assemble source; update output pane. Returns True on success."""
        source = self._editor.toPlainText()
        self._output.clear()
        self._error_output.setText("")
        self._last_words = None
        try:
            words = assemble(source)
        except AssemblyError as exc:
            self._error_output.setText(f"Assembler error: {exc}")
            return False
        hex_text = format_hex(words)
        self._last_words = words
        self._output.setPlainText(hex_text.strip())
        self.status_message.emit(
            f"Assembled OK: {len(words)} word(s)  ({len(words) * 2} bytes)"
        )
        return True

    def _assemble_and_load(self) -> None:
        if not self._assemble():
            return
        if self._last_words:
            self.load_words_requested.emit(self._last_words)

    def _copy_hex(self) -> None:
        from PySide6.QtWidgets import QApplication
        text = self._output.toPlainText()
        if text:
            QApplication.clipboard().setText(text)
            self.status_message.emit("Hex copied to clipboard")

    def _save_hex(self) -> None:
        if not self._last_words:
            QMessageBox.information(self, "No hex", "Assemble first to generate machine code.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save .hex file", "",
            "Hex files (*.hex);;All files (*.*)"
        )
        if not path:
            return
        try:
            Path(path).write_text(format_hex(self._last_words), encoding="ascii")
            self.status_message.emit(f"Saved {Path(path).name}")
        except OSError as exc:
            QMessageBox.critical(self, "Save failed", str(exc))

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def set_source(self, text: str) -> None:
        self._editor.setPlainText(text)
        self._modified = False
        self._update_title()
