"""CPU monitor widget — displays R0..RF, PC, SP, flags, and current instruction."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QColor
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QGroupBox, QFrame, QSizePolicy,
)

from .style import PALETTE, mono_font, label_font


class _HexLabel(QLabel):
    """A fixed-width label that shows a four-digit hexadecimal value."""

    def __init__(self, parent=None) -> None:
        super().__init__("0000", parent)
        self.setFont(mono_font())
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumWidth(52)
        self._highlighted = False
        self._apply_style()

    def _apply_style(self) -> None:
        bg = PALETTE["accent_dim"] if self._highlighted else PALETTE["surface"]
        self.setStyleSheet(
            f"color: {PALETTE['hex_value']}; background: {bg}; "
            f"border: 1px solid {PALETTE['border']}; border-radius: 3px; padding: 2px 6px;"
        )

    def set_value(self, value: int) -> None:
        self.setText(f"{value:04X}")

    def set_highlighted(self, on: bool) -> None:
        if on != self._highlighted:
            self._highlighted = on
            self._apply_style()


class _FlagLabel(QLabel):
    """Small label that is bright when the flag is set."""

    def __init__(self, name: str, parent=None) -> None:
        super().__init__(name, parent)
        self._name = name
        self.setFont(mono_font())
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumWidth(28)
        self.set_flag(False)

    def set_flag(self, on: bool) -> None:
        if on:
            color = PALETTE["flag_set"]
            bg = PALETTE["flag_set_bg"]
        else:
            color = PALETTE["flag_clear"]
            bg = PALETTE["surface"]
        self.setStyleSheet(
            f"color: {color}; background: {bg}; "
            f"border: 1px solid {PALETTE['border']}; border-radius: 3px; "
            f"padding: 1px 4px; font-weight: {'bold' if on else 'normal'};"
        )


class CPUView(QWidget):
    """Displays the full CPU state: R0–RF, PC, SP, flags, current instruction."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._reg_labels: list[_HexLabel] = []
        self._flag_labels: dict[str, _FlagLabel] = {}
        self._pc_label = _HexLabel()
        self._sp_label = _HexLabel()
        self._status_label = QLabel("READY")
        self._instr_label = QLabel("—")
        self._error_label = QLabel("")
        self._count_label = QLabel("0000")
        self._build_ui()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)

        # ── Registers ─────────────────────────────────────────────────
        reg_box = QGroupBox("General Registers  R0 – RF")
        reg_box.setStyleSheet(self._box_style())
        grid = QGridLayout(reg_box)
        grid.setSpacing(4)
        for i in range(16):
            name = QLabel(f"R{i:X}")
            name.setFont(label_font())
            name.setStyleSheet(f"color: {PALETTE['label']}; background: transparent;")
            name.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            lbl = _HexLabel()
            self._reg_labels.append(lbl)
            col = (i % 8) * 2
            row = i // 8
            grid.addWidget(name, row, col)
            grid.addWidget(lbl, row, col + 1)
        root.addWidget(reg_box)

        # ── PC / SP / flags ───────────────────────────────────────────
        state_row = QHBoxLayout()
        state_row.setSpacing(8)

        def _small_group(title, widget):
            box = QGroupBox(title)
            box.setStyleSheet(self._box_style())
            lay = QVBoxLayout(box)
            lay.setContentsMargins(6, 4, 6, 4)
            lay.addWidget(widget, alignment=Qt.AlignCenter)
            return box

        state_row.addWidget(_small_group("PC", self._pc_label))
        state_row.addWidget(_small_group("SP", self._sp_label))

        flag_box = QGroupBox("Flags")
        flag_box.setStyleSheet(self._box_style())
        flag_row = QHBoxLayout(flag_box)
        flag_row.setContentsMargins(6, 4, 6, 4)
        for name in ("Z", "N", "C", "V"):
            fl = _FlagLabel(name)
            self._flag_labels[name] = fl
            flag_row.addWidget(fl)
        state_row.addWidget(flag_box)
        state_row.addStretch()
        root.addLayout(state_row)

        # ── Status / instruction ───────────────────────────────────────
        info_box = QGroupBox("Execution State")
        info_box.setStyleSheet(self._box_style())
        info_lay = QVBoxLayout(info_box)
        info_lay.setContentsMargins(8, 4, 8, 4)

        self._status_label.setFont(label_font(bold=True))
        self._status_label.setAlignment(Qt.AlignCenter)
        self._status_label.setStyleSheet(
            f"color: {PALETTE['status_ready']}; background: transparent; font-size: 13px;"
        )

        self._instr_label.setFont(mono_font())
        self._instr_label.setAlignment(Qt.AlignCenter)
        self._instr_label.setStyleSheet(
            f"color: {PALETTE['hex_value']}; background: transparent;"
        )

        self._error_label.setFont(label_font())
        self._error_label.setAlignment(Qt.AlignCenter)
        self._error_label.setWordWrap(True)
        self._error_label.setStyleSheet(
            f"color: {PALETTE['error']}; background: transparent;"
        )

        cnt_row = QHBoxLayout()
        cnt_label = QLabel("Instructions executed:")
        cnt_label.setFont(label_font())
        cnt_label.setStyleSheet(f"color: {PALETTE['label']}; background: transparent;")
        self._count_label.setFont(mono_font())
        self._count_label.setStyleSheet(f"color: {PALETTE['hex_value']}; background: transparent;")
        cnt_row.addWidget(cnt_label)
        cnt_row.addWidget(self._count_label)
        cnt_row.addStretch()

        info_lay.addWidget(self._status_label)
        info_lay.addWidget(self._instr_label)
        info_lay.addWidget(self._error_label)
        info_lay.addLayout(cnt_row)
        root.addWidget(info_box)

    @staticmethod
    def _box_style() -> str:
        return (
            f"QGroupBox {{ color: {PALETTE['label']}; border: 1px solid {PALETTE['border']}; "
            f"border-radius: 4px; margin-top: 8px; padding-top: 4px; background: {PALETTE['surface']}; }}"
            f"QGroupBox::title {{ subcontrol-origin: margin; left: 8px; "
            f"color: {PALETTE['label']}; background: {PALETTE['background']}; padding: 0 4px; }}"
        )

    def refresh(self, snapshot: dict, instruction_text: str = "", step_count: int = 0) -> None:
        """Update all widgets from a CPU state snapshot dict."""
        regs = snapshot["registers"]
        pc = snapshot["pc"]

        for i, val in enumerate(regs):
            self._reg_labels[i].set_value(val)

        self._pc_label.set_value(pc)
        self._sp_label.set_value(snapshot["sp"])

        flags = snapshot["flags"]
        self._flag_labels["Z"].set_flag(flags["z"])
        self._flag_labels["N"].set_flag(flags["n"])
        self._flag_labels["C"].set_flag(flags["c"])
        self._flag_labels["V"].set_flag(flags["v"])

        self._count_label.setText(f"{step_count:04X} ({step_count})")

        halted = snapshot["halted"]
        error = snapshot["error"]
        if error:
            self._status_label.setText("FAULTED")
            self._status_label.setStyleSheet(
                f"color: {PALETTE['error']}; background: transparent; font-size: 13px; font-weight: bold;"
            )
            self._error_label.setText(error)
        elif halted:
            self._status_label.setText("HALTED")
            self._status_label.setStyleSheet(
                f"color: {PALETTE['status_halted']}; background: transparent; font-size: 13px; font-weight: bold;"
            )
            self._error_label.setText("")
        else:
            self._status_label.setText("READY")
            self._status_label.setStyleSheet(
                f"color: {PALETTE['status_ready']}; background: transparent; font-size: 13px;"
            )
            self._error_label.setText("")

        self._instr_label.setText(
            f"PC={pc:04X}  {instruction_text}" if instruction_text else f"PC={pc:04X}"
        )
