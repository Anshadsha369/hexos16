"""HEXOS-16 main application window."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QTimer, Slot
from PySide6.QtGui import QKeySequence, QAction, QIcon
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QTabWidget, QLabel, QStatusBar,
    QPushButton, QSpinBox, QFileDialog, QMessageBox,
    QToolBar, QFrame, QSizePolicy,
)

from hexos16.shell import Shell
from .execution_controller import ExecutionController
from .cpu_view import CPUView
from .memory_view import MemoryView
from .editor_view import EditorView
from .console_view import ConsoleView
from .style import PALETTE, label_font, title_font, mono_font


class MainWindow(QMainWindow):
    """Top-level application window for the HEXOS-16 virtual computer."""

    WINDOW_TITLE = "HEXOS-16 Virtual Computer Simulator"

    def __init__(self, instruction_limit: int = 10_000, parent=None) -> None:
        super().__init__(parent)
        self._ctrl = ExecutionController(instruction_limit=instruction_limit)
        self._shell = Shell(kernel=self._ctrl.kernel)
        self._step_count = 0
        self._running = False

        # Refresh timer for intermediate UI updates during run
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(150)  # ms
        self._refresh_timer.timeout.connect(self._periodic_refresh)

        self._build_ui()
        self._connect_signals()
        self._refresh_all()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        self.setWindowTitle(self.WINDOW_TITLE)
        self.resize(1280, 800)
        self.setMinimumSize(900, 600)

        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        # ── Header ────────────────────────────────────────────────────
        root.addWidget(self._build_header())

        # ── Toolbar ───────────────────────────────────────────────────
        root.addWidget(self._build_toolbar())

        # ── Main content area ─────────────────────────────────────────
        self._tabs = QTabWidget()
        self._tabs.setDocumentMode(False)

        # CPU + Memory side-by-side
        self._cpu_view = CPUView()
        self._memory_view = MemoryView()
        self._memory_view.set_controller(self._ctrl)

        vm_widget = QWidget()
        vm_lay = QHBoxLayout(vm_widget)
        vm_lay.setContentsMargins(4, 4, 4, 4)
        vm_lay.setSpacing(8)

        cpu_frame = self._framed(self._cpu_view)
        mem_frame = self._framed(self._memory_view)
        vm_splitter = QSplitter(Qt.Horizontal)
        vm_splitter.addWidget(cpu_frame)
        vm_splitter.addWidget(mem_frame)
        vm_splitter.setSizes([420, 600])
        vm_lay.addWidget(vm_splitter)

        self._editor_view = EditorView()
        self._console_view = ConsoleView()
        self._console_view.set_shell(self._shell)

        self._tabs.addTab(vm_widget, "🖥  CPU + Memory")
        self._tabs.addTab(self._framed(self._editor_view), "📝  Assembly Editor")
        self._tabs.addTab(self._framed(self._console_view), "💻  Shell Console")

        root.addWidget(self._tabs, stretch=1)

        # ── Status bar ────────────────────────────────────────────────
        self.statusBar().setStyleSheet(
            f"background: {PALETTE['surface']}; color: {PALETTE['label']}; "
            f"border-top: 1px solid {PALETTE['border']};"
        )
        self._status_label = QLabel("Ready — HEXOS-16 virtual computer simulator")
        self.statusBar().addWidget(self._status_label, 1)

        self._pc_status = QLabel("PC: 0000")
        self._pc_status.setFont(mono_font(9))
        self._pc_status.setStyleSheet(f"color: {PALETTE['hex_value']};")
        self.statusBar().addPermanentWidget(self._pc_status)

    def _build_header(self) -> QWidget:
        frame = QFrame()
        frame.setStyleSheet(
            f"background: {PALETTE['surface']}; border: 1px solid {PALETTE['border']}; "
            f"border-radius: 6px;"
        )
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(12, 8, 12, 8)

        # Hex motif + title
        hex_label = QLabel("⬡")
        hex_label.setStyleSheet(
            f"color: {PALETTE['branding']}; font-size: 28px; background: transparent; "
            f"font-family: 'Segoe UI Symbol';"
        )
        title = QLabel("HEXOS-16")
        title.setFont(title_font(18))
        title.setStyleSheet(f"color: {PALETTE['branding']}; background: transparent;")

        sub = QLabel("Virtual Computer Simulator")
        sub.setFont(label_font(10))
        sub.setStyleSheet(f"color: {PALETTE['label']}; background: transparent;")

        lay.addWidget(hex_label)
        lay.addWidget(title)
        lay.addSpacing(8)
        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        sep.setStyleSheet(f"color: {PALETTE['border']}; background: transparent;")
        lay.addWidget(sep)
        lay.addSpacing(8)
        lay.addWidget(sub)
        lay.addStretch()

        # State badge
        self._state_badge = QLabel("● READY")
        self._state_badge.setFont(label_font(11, bold=True))
        self._state_badge.setStyleSheet(
            f"color: {PALETTE['status_ready']}; background: transparent;"
        )
        lay.addWidget(self._state_badge)

        return frame

    def _build_toolbar(self) -> QWidget:
        frame = QFrame()
        frame.setStyleSheet(
            f"background: {PALETTE['surface']}; border: 1px solid {PALETTE['border']}; "
            f"border-radius: 5px; padding: 2px;"
        )
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(8, 4, 8, 4)
        lay.setSpacing(6)

        def _btn(text, tip, shortcut=None, primary=False):
            b = QPushButton(text)
            b.setToolTip(tip + (f"  [{shortcut}]" if shortcut else ""))
            if primary:
                b.setStyleSheet(
                    f"background: {PALETTE['accent']}; color: white; font-weight: bold; "
                    f"border: none; border-radius: 5px; padding: 5px 16px;"
                )
            return b

        self._reset_btn   = _btn("↺  Reset",  "Reset CPU and RAM",          "Ctrl+R")
        self._load_btn    = _btn("📂  Load .hex",  "Load a .hex program file")
        self._step_btn    = _btn("▶  Step",   "Execute one instruction",     "F7")
        self._run_btn     = _btn("▶▶ Run",   "Run until HALT or limit",     "F5", primary=True)
        self._stop_btn    = _btn("⏹  Stop",   "Request stop",               "Escape")
        self._stop_btn.setEnabled(False)

        limit_lbl = QLabel("Limit:")
        limit_lbl.setFont(label_font())
        limit_lbl.setStyleSheet(f"color: {PALETTE['label']}; background: transparent;")
        self._limit_spin = QSpinBox()
        self._limit_spin.setRange(1, 10_000_000)
        self._limit_spin.setValue(10_000)
        self._limit_spin.setSingleStep(1000)
        self._limit_spin.setToolTip("Maximum instructions before forced stop")
        self._limit_spin.setStyleSheet(
            f"background: {PALETTE['surface2']}; color: {PALETTE['hex_value']}; "
            f"border: 1px solid {PALETTE['border']}; border-radius: 4px; padding: 3px 6px;"
        )

        lay.addWidget(self._reset_btn)
        lay.addWidget(self._load_btn)
        lay.addSpacing(8)
        lay.addWidget(self._step_btn)
        lay.addWidget(self._run_btn)
        lay.addWidget(self._stop_btn)
        lay.addSpacing(8)
        lay.addWidget(limit_lbl)
        lay.addWidget(self._limit_spin)
        lay.addStretch()

        # Keyboard shortcuts
        self._reset_btn.setShortcut(QKeySequence("Ctrl+R"))
        self._step_btn.setShortcut(QKeySequence("F7"))
        self._run_btn.setShortcut(QKeySequence("F5"))
        self._stop_btn.setShortcut(QKeySequence("Escape"))

        return frame

    @staticmethod
    def _framed(widget: QWidget) -> QFrame:
        frame = QFrame()
        frame.setStyleSheet(
            f"background: {PALETTE['background']}; border: 1px solid {PALETTE['border']}; "
            f"border-radius: 4px;"
        )
        lay = QVBoxLayout(frame)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.addWidget(widget)
        return frame

    # ------------------------------------------------------------------
    # Signal wiring
    # ------------------------------------------------------------------

    def _connect_signals(self) -> None:
        # Execution controller
        self._ctrl.state_changed.connect(self._on_state_changed)
        self._ctrl.message.connect(self._on_message)
        self._ctrl.error_occurred.connect(self._on_error)

        # Toolbar buttons
        self._reset_btn.clicked.connect(self._do_reset)
        self._load_btn.clicked.connect(self._do_load_file)
        self._step_btn.clicked.connect(self._do_step)
        self._run_btn.clicked.connect(self._do_run)
        self._stop_btn.clicked.connect(self._do_stop)

        # Editor signals
        self._editor_view.load_words_requested.connect(self._do_load_words)
        self._editor_view.status_message.connect(self._set_status)

        # Menu bar
        self._build_menu()

    def _build_menu(self) -> None:
        mb = self.menuBar()
        mb.setStyleSheet(
            f"background: {PALETTE['surface']}; color: {PALETTE['text']}; "
            f"border-bottom: 1px solid {PALETTE['border']};"
        )

        file_menu = mb.addMenu("&File")
        file_menu.setStyleSheet(
            f"background: {PALETTE['surface2']}; color: {PALETTE['text']}; "
            f"border: 1px solid {PALETTE['border']};"
        )
        act_load = file_menu.addAction("Load .hex program…")
        act_load.setShortcut(QKeySequence("Ctrl+O"))
        act_load.triggered.connect(self._do_load_file)

        act_editor = file_menu.addAction("Open editor")
        act_editor.triggered.connect(lambda: self._tabs.setCurrentIndex(1))
        file_menu.addSeparator()
        act_quit = file_menu.addAction("Exit")
        act_quit.setShortcut(QKeySequence("Alt+F4"))
        act_quit.triggered.connect(self.close)

        run_menu = mb.addMenu("&Run")
        run_menu.setStyleSheet(file_menu.styleSheet())
        r_step = run_menu.addAction("Step  [F7]")
        r_step.triggered.connect(self._do_step)
        r_run = run_menu.addAction("Run  [F5]")
        r_run.triggered.connect(self._do_run)
        r_stop = run_menu.addAction("Stop  [Esc]")
        r_stop.triggered.connect(self._do_stop)
        run_menu.addSeparator()
        r_reset = run_menu.addAction("Reset  [Ctrl+R]")
        r_reset.triggered.connect(self._do_reset)

        view_menu = mb.addMenu("&View")
        view_menu.setStyleSheet(file_menu.styleSheet())
        v_cpu = view_menu.addAction("CPU + Memory")
        v_cpu.triggered.connect(lambda: self._tabs.setCurrentIndex(0))
        v_ed = view_menu.addAction("Assembly Editor")
        v_ed.triggered.connect(lambda: self._tabs.setCurrentIndex(1))
        v_con = view_menu.addAction("Shell Console")
        v_con.triggered.connect(lambda: self._tabs.setCurrentIndex(2))

        help_menu = mb.addMenu("&Help")
        help_menu.setStyleSheet(file_menu.styleSheet())
        act_about = help_menu.addAction("About HEXOS-16")
        act_about.triggered.connect(self._show_about)

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    @Slot()
    def _do_reset(self) -> None:
        if self._ctrl.is_busy():
            self._do_stop()
            return
        msg = self._ctrl.reset()
        self._step_count = 0
        self._set_status(msg)
        self._refresh_all()

    @Slot()
    def _do_load_file(self) -> None:
        if self._ctrl.is_busy():
            self._set_status("Stop execution before loading a new program.")
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Load .hex program", "",
            "Hex files (*.hex);;All files (*.*)"
        )
        if not path:
            return
        msg = self._ctrl.load_file(path)
        if msg.startswith("ERROR"):
            QMessageBox.critical(self, "Load failed", msg)
        else:
            self._step_count = 0
            self._set_status(msg)
            self._refresh_all()

    @Slot(list)
    def _do_load_words(self, words: list) -> None:
        if self._ctrl.is_busy():
            self._set_status("Stop execution before loading a new program.")
            return
        msg = self._ctrl.load_words(words)
        if msg.startswith("ERROR"):
            QMessageBox.critical(self, "Load failed", msg)
        else:
            self._step_count = 0
            self._set_status(msg)
            self._refresh_all()
            self._tabs.setCurrentIndex(0)

    @Slot()
    def _do_step(self) -> None:
        if self._ctrl.is_busy():
            return
        self._ctrl.step_async()
        self._step_count += 1

    @Slot()
    def _do_run(self) -> None:
        if self._ctrl.is_busy():
            return
        limit = self._limit_spin.value()
        self._running = True
        self._update_run_state(running=True)
        self._refresh_timer.start()
        self._ctrl.run_async(limit)

    @Slot()
    def _do_stop(self) -> None:
        self._ctrl.stop()
        self._set_status("Stop requested…")

    # ------------------------------------------------------------------
    # Slots from controller
    # ------------------------------------------------------------------

    @Slot()
    def _on_state_changed(self) -> None:
        if self._running and not self._ctrl.is_busy():
            self._running = False
            self._update_run_state(running=False)
            self._refresh_timer.stop()
        self._refresh_all()

    @Slot(str)
    def _on_message(self, msg: str) -> None:
        self._set_status(msg)

    @Slot(str)
    def _on_error(self, msg: str) -> None:
        self._set_status(f"ERROR: {msg}")
        self._running = False
        self._update_run_state(running=False)
        self._refresh_timer.stop()
        self._refresh_all()

    @Slot()
    def _periodic_refresh(self) -> None:
        """Intermediate UI refresh while a run is in progress."""
        self._refresh_all()

    # ------------------------------------------------------------------
    # Refresh
    # ------------------------------------------------------------------

    def _refresh_all(self) -> None:
        snap = self._ctrl.cpu_snapshot()
        instr = self._ctrl.current_instruction_text()
        self._cpu_view.refresh(snap, instr, self._step_count)
        self._memory_view.refresh(pc=snap["pc"])

        pc = snap["pc"]
        self._pc_status.setText(f"PC: {pc:04X}")

        halted = snap["halted"]
        error = snap["error"]
        if error:
            self._state_badge.setText("● FAULTED")
            self._state_badge.setStyleSheet(
                f"color: {PALETTE['error']}; background: transparent;"
            )
        elif halted:
            self._state_badge.setText("● HALTED")
            self._state_badge.setStyleSheet(
                f"color: {PALETTE['status_halted']}; background: transparent;"
            )
        elif self._running:
            self._state_badge.setText("● RUNNING")
            self._state_badge.setStyleSheet(
                f"color: {PALETTE['accent']}; background: transparent;"
            )
        else:
            self._state_badge.setText("● READY")
            self._state_badge.setStyleSheet(
                f"color: {PALETTE['status_ready']}; background: transparent;"
            )

    def _update_run_state(self, running: bool) -> None:
        self._run_btn.setEnabled(not running)
        self._step_btn.setEnabled(not running)
        self._reset_btn.setEnabled(not running)
        self._load_btn.setEnabled(not running)
        self._stop_btn.setEnabled(running)

    def _set_status(self, msg: str) -> None:
        self._status_label.setText(msg)

    # ------------------------------------------------------------------
    # About dialog
    # ------------------------------------------------------------------

    def _show_about(self) -> None:
        QMessageBox.about(
            self, "About HEXOS-16",
            "<b>HEXOS-16 Virtual Computer Simulator</b><br><br>"
            "An experimental 16-bit virtual CPU running entirely in software "
            "on the host operating system.<br><br>"
            "<b>Architecture:</b> 16-bit word CPU, R0–RF, 256-word ROM, "
            "4096-word RAM, hexadecimal ISA<br>"
            "<b>Memory map:</b> ROM 0000–00FF, RAM 0100–10FF<br>"
            "<b>Host PC, RAM, firmware, and storage are not modified.</b><br><br>"
            "No host commands are ever executed by the simulator shell."
        )

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def closeEvent(self, event) -> None:
        self._refresh_timer.stop()
        self._ctrl.stop()
        self._ctrl.shutdown()
        super().closeEvent(event)
