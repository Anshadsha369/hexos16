"""Thread-safe execution controller for HEXOS-16 GUI.

The controller owns a Kernel instance and runs CPU execution on a
QThread so the GUI thread never blocks.  All state changes emit Qt
signals so that GUI widgets can update safely on the main thread.

Concurrency rules
-----------------
* ``kernel`` must only be accessed while holding ``_lock``.
* GUI widgets must not call kernel methods directly.
* Use the public slot methods (load_words, step, run, reset) which
  acquire the lock and post work to the worker thread (or run
  synchronously for cheap operations).
* Signals are always emitted on the worker thread and delivered by Qt
  to connected slots on the main thread via the event loop.
"""

from __future__ import annotations

import threading
from typing import List, Optional

from PySide6.QtCore import QObject, QThread, Signal, Slot

from hexos16.kernel import Kernel, KernelError
from hexos16.assembler import assemble, format_hex, AssemblyError
from hexos16.disassembler import disassemble


class _Worker(QObject):
    """Runs blocking kernel operations on a dedicated thread."""

    # Emitted after every state change
    state_changed = Signal()
    # Emitted with an informational message
    message = Signal(str)
    # Emitted on any error (kernel or unexpected)
    error_occurred = Signal(str)

    def __init__(self, controller: "ExecutionController") -> None:
        super().__init__()
        self._ctrl = controller

    @Slot()
    def do_step(self) -> None:
        ctrl = self._ctrl
        with ctrl._lock:
            if ctrl._busy:
                self.error_occurred.emit("busy: another operation is running")
                return
            ctrl._busy = True
        try:
            with ctrl._lock:
                before = ctrl.kernel.cpu.pc
            try:
                with ctrl._lock:
                    ctrl.kernel.step()
            except KernelError as exc:
                self.error_occurred.emit(str(exc))
                return
            with ctrl._lock:
                after = ctrl.kernel.cpu.pc
                halted = ctrl.kernel.cpu.halted
            msg = f"step at {before:04X}; PC={after:04X}"
            if halted:
                msg += " HALTED"
            self.message.emit(msg)
        finally:
            with ctrl._lock:
                ctrl._busy = False
            self.state_changed.emit()

    @Slot(int)
    def do_run(self, limit: int) -> None:
        ctrl = self._ctrl
        with ctrl._lock:
            if ctrl._busy:
                self.error_occurred.emit("busy: another operation is running")
                return
            ctrl._busy = True
            ctrl._stop_requested = False
        try:
            # Run in chunks so we can respond to stop requests.
            chunk = 500
            total = 0
            while True:
                with ctrl._lock:
                    if ctrl._stop_requested:
                        self.message.emit(f"stopped by user at PC={ctrl.kernel.cpu.pc:04X}")
                        return
                    if ctrl.kernel.cpu.halted or ctrl.kernel.cpu.error is not None:
                        break
                    remaining = limit - total
                    if remaining <= 0:
                        self.error_occurred.emit(
                            f"instruction limit {limit} reached at PC={ctrl.kernel.cpu.pc:04X}"
                        )
                        return
                    steps_this_chunk = min(chunk, remaining)
                # Run one chunk without the lock so stop_requested can be set
                try:
                    with ctrl._lock:
                        for _ in range(steps_this_chunk):
                            if ctrl.kernel.cpu.halted or ctrl.kernel.cpu.error is not None:
                                break
                            ctrl.kernel.step()
                            total += 1
                            if total >= limit:
                                break
                except KernelError as exc:
                    self.error_occurred.emit(str(exc))
                    return
                with ctrl._lock:
                    if ctrl.kernel.cpu.halted:
                        break
                self.state_changed.emit()  # intermediate refresh
            with ctrl._lock:
                pc = ctrl.kernel.cpu.pc
            self.message.emit(f"halted after {total:04X} instruction(s); PC={pc:04X}")
        finally:
            with ctrl._lock:
                ctrl._busy = False
            self.state_changed.emit()


class ExecutionController(QObject):
    """Public interface for the GUI to control the HEXOS-16 virtual machine.

    This object lives on the main (GUI) thread.  Heavy work is delegated
    to ``_Worker`` which runs on ``_thread``.
    """

    # Forwarded from worker
    state_changed = Signal()
    message = Signal(str)
    error_occurred = Signal(str)

    def __init__(self, instruction_limit: int = 10_000, parent=None) -> None:
        super().__init__(parent)
        self._lock = threading.Lock()
        self.kernel = Kernel(instruction_limit=instruction_limit)
        self._busy = False
        self._stop_requested = False
        self._instruction_limit = instruction_limit

        self._thread = QThread(self)
        self._worker = _Worker(self)
        self._worker.moveToThread(self._thread)

        # Wire worker signals through to controller signals
        self._worker.state_changed.connect(self.state_changed)
        self._worker.message.connect(self.message)
        self._worker.error_occurred.connect(self.error_occurred)

        self._thread.start()

    def stop(self) -> None:
        """Request that an in-progress run stops at the next chunk boundary."""
        with self._lock:
            self._stop_requested = True

    def is_busy(self) -> bool:
        with self._lock:
            return self._busy

    # ------------------------------------------------------------------
    # Synchronous operations (cheap, safe to call from GUI thread)
    # ------------------------------------------------------------------

    def reset(self) -> str:
        """Reset kernel state; returns a status message."""
        with self._lock:
            if self._busy:
                return "ERROR: cannot reset while execution is running"
            msg = self.kernel.reset()
        self.state_changed.emit()
        return msg

    def load_words(self, words: List[int]) -> str:
        """Load a validated word list into RAM."""
        with self._lock:
            if self._busy:
                return "ERROR: cannot load while execution is running"
            try:
                msg = self.kernel.load_words(words)
            except KernelError as exc:
                return f"ERROR: {exc}"
        self.state_changed.emit()
        return msg

    def load_file(self, path: str) -> str:
        """Load a .hex file through the kernel loader."""
        with self._lock:
            if self._busy:
                return "ERROR: cannot load while execution is running"
            try:
                msg = self.kernel.load_file(path)
            except KernelError as exc:
                return f"ERROR: {exc}"
        self.state_changed.emit()
        return msg

    def assemble_source(self, source: str):
        """Assemble source text; returns (words, hex_text) or raises AssemblyError."""
        words = assemble(source)
        return words, format_hex(words)

    # ------------------------------------------------------------------
    # Asynchronous operations (posted to worker thread)
    # ------------------------------------------------------------------

    def step_async(self) -> None:
        """Execute one instruction on the worker thread."""
        from PySide6.QtCore import QMetaObject, Qt
        QMetaObject.invokeMethod(self._worker, "do_step", Qt.QueuedConnection)

    def run_async(self, limit: Optional[int] = None) -> None:
        """Run until HALT, fault, or limit on the worker thread."""
        from PySide6.QtCore import QMetaObject, Qt, Q_ARG
        effective_limit = limit if limit is not None else self._instruction_limit
        QMetaObject.invokeMethod(
            self._worker, "do_run", Qt.QueuedConnection,
            Q_ARG(int, effective_limit),
        )

    # ------------------------------------------------------------------
    # Read-only CPU state snapshots (safe to call from GUI thread with lock)
    # ------------------------------------------------------------------

    def cpu_snapshot(self) -> dict:
        """Return a dictionary of current CPU state (copy, thread-safe)."""
        with self._lock:
            cpu = self.kernel.cpu
            return {
                "registers": list(cpu.registers),
                "pc": cpu.pc,
                "sp": cpu.sp,
                "flags": {
                    "z": cpu.flags.z,
                    "n": cpu.flags.n,
                    "c": cpu.flags.c,
                    "v": cpu.flags.v,
                },
                "halted": cpu.halted,
                "error": str(cpu.error) if cpu.error else None,
            }

    def memory_words(self, address: int, count: int) -> List[tuple]:
        """Read ``count`` words from the bus starting at ``address``."""
        with self._lock:
            try:
                return self.kernel.inspect(address, count)
            except (IndexError, KernelError) as exc:
                raise IndexError(str(exc)) from exc

    def disassemble_at(self, address: int, count: int = 16) -> List[str]:
        """Disassemble ``count`` words from the bus starting at ``address``."""
        with self._lock:
            try:
                pairs = self.kernel.inspect(address, count)
            except (IndexError, KernelError):
                return []
        words = [int(v, 16) for _, v in pairs]
        return disassemble(words, start=address)

    def current_instruction_text(self) -> str:
        """Return disassembled text for the instruction at current PC, or ''."""
        with self._lock:
            pc = self.kernel.cpu.pc
        lines = self.disassemble_at(pc, 1)
        if lines:
            return lines[0].split(": ", 1)[-1]
        return ""

    def shutdown(self) -> None:
        """Stop the worker thread cleanly."""
        self._thread.quit()
        self._thread.wait(3000)
