"""Entry point for the HEXOS-16 graphical desktop application."""

from __future__ import annotations

import sys
import os


def main() -> None:
    # Use offscreen platform when running in headless environments.
    if "QT_QPA_PLATFORM" not in os.environ and "--offscreen" in sys.argv:
        os.environ["QT_QPA_PLATFORM"] = "offscreen"

    from PySide6.QtWidgets import QApplication
    from hexos16.gui.main_window import MainWindow
    from hexos16.gui.style import APP_STYLESHEET

    app = QApplication(sys.argv)
    app.setApplicationName("HEXOS-16")
    app.setApplicationVersion("0.2.0")
    app.setOrganizationName("HEXOS-16 Project")
    app.setStyleSheet(APP_STYLESHEET)

    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
