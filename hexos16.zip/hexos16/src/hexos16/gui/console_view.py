"""HEXOS-16 restricted shell console widget.

Accepts only the documented HEXOS-16 shell commands.  Never passes
input to a host command interpreter.
"""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont, QTextCursor, QColor, QKeyEvent
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QTextEdit, QPushButton, QSizePolicy,
)

from .style import PALETTE, mono_font, label_font


class ConsoleView(QWidget):
    """Terminal-like widget that drives the HEXOS-16 Shell object."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._shell = None          # set via set_shell()
        self._history: list[str] = []
        self._history_pos = -1
        self._build_ui()

    def set_shell(self, shell) -> None:
        self._shell = shell
        self._print_system("HEXOS-16 Virtual Computer Console")
        self._print_system("Type HELP for a list of commands.")
        self._print_system("Shell commands never execute on the host system.")
        self._print_prompt()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Output area ───────────────────────────────────────────────
        self._output = QTextEdit()
        self._output.setReadOnly(True)
        self._output.setFont(mono_font(10))
        self._output.setStyleSheet(
            f"background: {PALETTE['console_bg']}; color: {PALETTE['console_text']}; "
            f"border: 1px solid {PALETTE['border']}; border-radius: 4px 4px 0 0;"
        )
        root.addWidget(self._output, stretch=1)

        # ── Input row ────────────────────────────────────────────────
        input_row = QHBoxLayout()
        input_row.setContentsMargins(0, 2, 0, 0)
        input_row.setSpacing(4)

        prompt_lbl = QLabel("HEXOS16>")
        prompt_lbl.setFont(mono_font(10))
        prompt_lbl.setStyleSheet(
            f"color: {PALETTE['accent']}; background: {PALETTE['console_bg']}; "
            f"padding: 4px 6px; border: 1px solid {PALETTE['border']}; "
            f"border-right: none; border-radius: 0 0 0 4px;"
        )

        self._input = _HistoryLineEdit(self._history)
        self._input.setFont(mono_font(10))
        self._input.setStyleSheet(
            f"background: {PALETTE['console_bg']}; color: {PALETTE['console_cmd']}; "
            f"border: 1px solid {PALETTE['border']}; border-left: none; "
            f"border-radius: 0 0 4px 0; padding: 4px 8px;"
        )
        self._input.returnPressed.connect(self._submit)

        send_btn = QPushButton("Send")
        send_btn.setMaximumWidth(60)
        send_btn.clicked.connect(self._submit)
        send_btn.setStyleSheet(
            f"background: {PALETTE['accent']}; color: white; border: none; "
            f"border-radius: 4px; padding: 4px 10px; margin-left: 4px;"
        )

        clear_btn = QPushButton("Clear")
        clear_btn.setMaximumWidth(60)
        clear_btn.clicked.connect(self._clear)
        clear_btn.setStyleSheet(
            f"background: {PALETTE['surface2']}; color: {PALETTE['label']}; "
            f"border: 1px solid {PALETTE['border']}; border-radius: 4px; padding: 4px 10px;"
        )

        input_row.addWidget(prompt_lbl)
        input_row.addWidget(self._input, stretch=1)
        input_row.addWidget(send_btn)
        input_row.addWidget(clear_btn)
        root.addLayout(input_row)

    def _submit(self) -> None:
        line = self._input.text().strip()
        self._input.clear()
        if not line:
            self._print_prompt()
            return
        # Record in history
        if line and (not self._history or self._history[-1] != line):
            self._history.append(line)
        self._print_command(line)
        if self._shell is None:
            self._print_error("Shell not initialized.")
        else:
            result = self._shell.execute(line)
            if result:
                self._print_output(result)
        self._print_prompt()

    def _clear(self) -> None:
        self._output.clear()
        if self._shell:
            self._print_prompt()

    def _append(self, text: str, color: str) -> None:
        cursor = self._output.textCursor()
        cursor.movePosition(QTextCursor.End)
        fmt = cursor.charFormat()
        fmt.setForeground(QColor(color))
        cursor.setCharFormat(fmt)
        cursor.insertText(text + "\n")
        self._output.setTextCursor(cursor)
        self._output.ensureCursorVisible()

    def _print_system(self, msg: str) -> None:
        self._append(f"# {msg}", PALETTE["label"])

    def _print_prompt(self) -> None:
        cursor = self._output.textCursor()
        cursor.movePosition(QTextCursor.End)
        fmt = cursor.charFormat()
        fmt.setForeground(QColor(PALETTE["accent"]))
        cursor.setCharFormat(fmt)
        cursor.insertText("HEXOS16> ")
        self._output.setTextCursor(cursor)

    def _print_command(self, cmd: str) -> None:
        cursor = self._output.textCursor()
        cursor.movePosition(QTextCursor.End)
        fmt = cursor.charFormat()
        fmt.setForeground(QColor(PALETTE["console_cmd"]))
        cursor.setCharFormat(fmt)
        cursor.insertText(cmd + "\n")
        self._output.setTextCursor(cursor)

    def _print_output(self, text: str) -> None:
        color = PALETTE["error"] if text.startswith("ERROR") else PALETTE["console_text"]
        self._append(text, color)

    def _print_error(self, msg: str) -> None:
        self._append(f"ERROR: {msg}", PALETTE["error"])

    def append_message(self, msg: str) -> None:
        """Called from the main window to display status messages."""
        self._print_system(msg)


class _HistoryLineEdit(QLineEdit):
    """Line edit that supports ↑/↓ command history navigation."""

    def __init__(self, history: list[str], parent=None) -> None:
        super().__init__(parent)
        self._history = history
        self._pos = -1

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() == Qt.Key_Up:
            if self._history:
                self._pos = max(0, (self._pos - 1) if self._pos >= 0 else len(self._history) - 1)
                self.setText(self._history[self._pos])
        elif event.key() == Qt.Key_Down:
            if self._pos >= 0:
                self._pos += 1
                if self._pos >= len(self._history):
                    self._pos = -1
                    self.clear()
                else:
                    self.setText(self._history[self._pos])
        else:
            self._pos = -1
            super().keyPressEvent(event)
