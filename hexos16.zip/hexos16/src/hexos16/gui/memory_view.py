"""Memory viewer widget — word-addressed hex grid with ROM/RAM distinction."""

from __future__ import annotations

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QColor
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QScrollArea, QGridLayout, QGroupBox,
    QSpinBox, QFrame, QSizePolicy,
)

from hexos16.memory import MemoryBus
from .style import PALETTE, mono_font, label_font


_ROM_START = MemoryBus.ROM_START   # 0x0000
_ROM_END   = MemoryBus.ROM_END     # 0x00FF
_RAM_START = MemoryBus.RAM_START   # 0x0100
_RAM_END   = MemoryBus.RAM_END     # 0x10FF


class _WordCell(QLabel):
    """Single memory-word display cell."""

    def __init__(self, address: int, parent=None) -> None:
        super().__init__("0000", parent)
        self._address = address
        self._is_pc = False
        self._region = self._classify(address)
        self.setFont(mono_font(10))
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumWidth(46)
        self._apply_style()

    @staticmethod
    def _classify(address: int) -> str:
        if _ROM_START <= address <= _ROM_END:
            return "rom"
        if _RAM_START <= address <= _RAM_END:
            return "ram"
        return "unmapped"

    def _apply_style(self) -> None:
        if self._is_pc:
            bg = PALETTE["accent_dim"]
            border = PALETTE["accent"]
            fg = "#FFFFFF"
        elif self._region == "rom":
            bg = PALETTE["rom_bg"]
            border = PALETTE["border"]
            fg = PALETTE["rom_fg"]
        elif self._region == "ram":
            bg = PALETTE["ram_bg"]
            border = PALETTE["border"]
            fg = PALETTE["ram_fg"]
        else:
            bg = PALETTE["surface"]
            border = PALETTE["separator"]
            fg = PALETTE["label"]
        self.setStyleSheet(
            f"color: {fg}; background: {bg}; border: 1px solid {border}; "
            f"border-radius: 2px; padding: 1px 3px;"
        )

    def set_word(self, value: int, is_pc: bool = False) -> None:
        self.setText(f"{value:04X}")
        if is_pc != self._is_pc:
            self._is_pc = is_pc
            self._apply_style()


class MemoryView(QWidget):
    """Scrollable word-addressed memory viewer with ROM/RAM colour coding."""

    COLS = 8          # words per row
    ROWS = 16         # visible rows

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._ctrl = None          # set via set_controller()
        self._start_addr = 0x0000  # top-left address in current view
        self._current_pc = 0x0000
        self._cells: dict[int, _WordCell] = {}
        self._addr_labels: list[QLabel] = []
        self._build_ui()

    def set_controller(self, ctrl) -> None:
        self._ctrl = ctrl

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)

        # ── Navigation bar ─────────────────────────────────────────────
        nav = QHBoxLayout()
        nav.setSpacing(6)

        addr_lbl = QLabel("Address:")
        addr_lbl.setFont(label_font())
        addr_lbl.setStyleSheet(f"color: {PALETTE['label']};")
        self._addr_input = QLineEdit("0000")
        self._addr_input.setFont(mono_font(10))
        self._addr_input.setMaximumWidth(70)
        self._addr_input.setPlaceholderText("0000..10FF")
        self._addr_input.setToolTip("Word address in hexadecimal (0000–10FF)")
        self._addr_input.returnPressed.connect(self._go_to_address)

        go_btn = QPushButton("Go")
        go_btn.setMaximumWidth(50)
        go_btn.clicked.connect(self._go_to_address)

        rom_btn = QPushButton("ROM (0000)")
        rom_btn.clicked.connect(lambda: self._jump(0x0000))
        ram_btn = QPushButton("RAM (0100)")
        ram_btn.clicked.connect(lambda: self._jump(0x0100))
        pc_btn = QPushButton("→ PC")
        pc_btn.clicked.connect(self._follow_pc)
        pc_btn.setToolTip("Jump to current PC address")

        nav.addWidget(addr_lbl)
        nav.addWidget(self._addr_input)
        nav.addWidget(go_btn)
        nav.addSpacing(8)
        nav.addWidget(rom_btn)
        nav.addWidget(ram_btn)
        nav.addWidget(pc_btn)
        nav.addStretch()
        root.addLayout(nav)

        # ── Legend ────────────────────────────────────────────────────
        legend = QHBoxLayout()
        legend.setSpacing(12)
        for label_text, fg, bg in (
            ("ROM  0000–00FF", PALETTE["rom_fg"], PALETTE["rom_bg"]),
            ("RAM  0100–10FF", PALETTE["ram_fg"], PALETTE["ram_bg"]),
            ("PC", "#FFFFFF", PALETTE["accent_dim"]),
        ):
            swatch = QLabel(label_text)
            swatch.setFont(label_font(9))
            swatch.setStyleSheet(
                f"color: {fg}; background: {bg}; border: 1px solid {PALETTE['border']}; "
                f"border-radius: 3px; padding: 1px 6px;"
            )
            legend.addWidget(swatch)
        legend.addStretch()
        root.addLayout(legend)

        # ── Grid ──────────────────────────────────────────────────────
        self._error_label = QLabel("")
        self._error_label.setStyleSheet(f"color: {PALETTE['error']};")
        self._error_label.setFont(label_font())
        root.addWidget(self._error_label)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        container = QWidget()
        self._grid = QGridLayout(container)
        self._grid.setSpacing(2)
        self._grid.setContentsMargins(4, 4, 4, 4)

        # Header row
        for col in range(self.COLS):
            h = QLabel(f"+{col:X}")
            h.setFont(label_font(9))
            h.setAlignment(Qt.AlignCenter)
            h.setStyleSheet(f"color: {PALETTE['label']};")
            self._grid.addWidget(h, 0, col + 1)

        # Rows
        for row in range(self.ROWS):
            row_lbl = QLabel("????")
            row_lbl.setFont(mono_font(10))
            row_lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            row_lbl.setStyleSheet(f"color: {PALETTE['label']};")
            self._addr_labels.append(row_lbl)
            self._grid.addWidget(row_lbl, row + 1, 0)
            for col in range(self.COLS):
                addr = row * self.COLS + col  # placeholder, updated in refresh
                cell = _WordCell(addr)
                self._cells[(row, col)] = cell
                self._grid.addWidget(cell, row + 1, col + 1)

        scroll.setWidget(container)
        root.addWidget(scroll, stretch=1)

    def _go_to_address(self) -> None:
        text = self._addr_input.text().strip()
        try:
            addr = int(text, 16)
        except ValueError:
            self._error_label.setText(f"Invalid address: {text!r} — enter hexadecimal e.g. 0100")
            return
        self._error_label.setText("")
        self._jump(addr)

    def _jump(self, addr: int) -> None:
        # Align to column boundary
        addr = (addr // self.COLS) * self.COLS
        self._start_addr = addr
        self._addr_input.setText(f"{addr:04X}")
        self.refresh()

    def _follow_pc(self) -> None:
        self._jump(self._current_pc)

    def refresh(self, pc: int | None = None) -> None:
        """Reload all visible cells from the controller."""
        if pc is not None:
            self._current_pc = pc

        if self._ctrl is None:
            return

        total = self.ROWS * self.COLS
        base = self._start_addr

        for row in range(self.ROWS):
            row_addr = base + row * self.COLS
            # Update row address label
            lbl = self._addr_labels[row]
            if 0 <= row_addr <= 0xFFFF:
                lbl.setText(f"{row_addr:04X}")
            else:
                lbl.setText("——")
            for col in range(self.COLS):
                addr = row_addr + col
                cell = self._cells[(row, col)]
                # Re-create cell if address changed
                if cell._address != addr:
                    new_cell = _WordCell(addr)
                    self._grid.replaceWidget(cell, new_cell)
                    cell.deleteLater()
                    self._cells[(row, col)] = new_cell
                    cell = new_cell
                is_pc = (addr == self._current_pc)
                if 0 <= addr <= 0xFFFF:
                    try:
                        pairs = self._ctrl.memory_words(addr, 1)
                        val = int(pairs[0][1], 16)
                        cell.set_word(val, is_pc)
                    except (IndexError, Exception):
                        cell.set_word(0, is_pc)
                        cell.setText("——")
                else:
                    cell.set_word(0, is_pc)
                    cell.setText("——")
