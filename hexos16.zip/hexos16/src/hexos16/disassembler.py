"""Canonical one-word HEXOS-16 disassembler."""


def disassemble(words, start=0):
    result = []
    words = list(words)
    names = {0: "NOP", 1: "LDI", 2: "MOV", 3: "ADD", 4: "SUB", 5: "AND", 6: "OR", 7: "XOR",
             8: "CMP", 9: "BR", 10: "BZ", 11: "BNZ", 12: "BC", 13: "HALT", 14: "LD", 15: "ST"}
    offset = 0
    while offset < len(words):
        word = words[offset]
        address = start + offset
        if not isinstance(word, int) or isinstance(word, bool) or not 0 <= word <= 0xFFFF:
            result.append(f"{address:04X}: .WORD {word!r}")
            continue
        op, d, a, b = word >> 12, (word >> 8) & 0xF, (word >> 4) & 0xF, word & 0xF
        valid = True
        if word != 0 and op == 0 and (word & 0xF0F0) == 0x0010:
            if offset + 1 >= len(words) or not isinstance(words[offset + 1], int) or isinstance(words[offset + 1], bool) or not 0 <= words[offset + 1] <= 0xFFFF:
                text = f".WORD 0x{word:04X}"
            else:
                text = f"LDI16 R{d:X}, 0x{words[offset + 1]:04X}"
                result.append(f"{address:04X}: {text}")
                result.append(f"{address + 1:04X}: .DATA 0x{words[offset + 1]:04X}")
                offset += 2
                continue
        elif op == 0: text = "NOP"; valid = word == 0
        elif op == 1: text = f"LDI R{d:X}, {b}"
        elif op == 2: text = f"MOV R{d:X}, R{a:X}"; valid = b == 0
        elif 3 <= op <= 7: text = f"{names[op]} R{d:X}, R{a:X}, R{b:X}"
        elif op == 8: text = f"CMP R{a:X}, R{b:X}"; valid = d == 0
        elif 9 <= op <= 12:
            disp = word & 0xFF
            if disp & 0x80: disp -= 0x100
            text = f"{names[op]} {disp:+d}"; valid = d == 0
        elif op == 13: text = "HALT"; valid = word == 0xD000
        elif op in (14, 15): text = f"{names[op]} R{d:X}, R{a:X}"; valid = b == 0
        if not valid:
            text = f".WORD 0x{word:04X}"
        result.append(f"{address:04X}: {text}")
        offset += 1
    return result
