# HEXOS-16 software virtual machine and shell

HEXOS-16 is a software-defined virtual machine. Its CPU and simulated memory use ordinary host memory; no host CPU, physical RAM, firmware, partitions, bootloader, or phone storage is modified. See [docs/isa.md](docs/isa.md) for instruction encodings, flags, and the memory map.

Run tests from this directory with PowerShell:

```powershell
$env:PYTHONPATH = 'src'
$env:QT_QPA_PLATFORM = 'offscreen'
python -m unittest discover -s tests -v
```

The Python package has no runtime dependencies. RAM contains 4,096 words (`0000–0FFF` within its own object); ROM contains 256 read-only words (`0000–00FF` within its object). When connected to the CPU through `MemoryBus`, ROM occupies CPU word addresses `0000–00FF`, RAM occupies `0100–10FF`, and all other addresses are unmapped. PC values count words. Short ROM images are padded with zero words. The legacy flat CPU program mode remains for compatibility.

Example memory setup:

```python
from hexos16 import CPU, MemoryBus, RAM, ROM

cpu = CPU(memory=MemoryBus(rom=ROM([0x1102, 0xD000]), ram=RAM()))
cpu.step()
```

Assembler and disassembler APIs:

```python
from hexos16 import assemble, disassemble, format_hex

words = assemble("LDI R1, 2\nLDI R2, 3\nADD R3, R1, R2\nHALT")
print(format_hex(words))
print("\n".join(disassemble(words)))
```

Bare numeric literals are decimal; prefix hexadecimal literals with `0x`. Labels resolve branch targets to signed 8-bit word displacements from the next instruction. `LDI` loads a four-bit immediate; `LDI16` loads a full word using a two-word encoding. The deterministic `.hex` format contains one uppercase four-digit word per line. The disassembler emits canonical assembly and `.DATA` lines for LDI16 extension words; `.WORD` denotes invalid encodings. Valid canonical disassembly can be reassembled to identical words. Label names and original source formatting are not preserved.

See [examples/store_load.asm](examples/store_load.asm) for a program that computes `2 + 3`, stores the result in simulated RAM at CPU address `0100`, loads it again, and halts.

## Kernel and shell

Run the text shell after installing the package with `python -m pip install -e .`, then execute `hexos16`. You can also run `python -m hexos16.shell` with `PYTHONPATH=src`. The shell supports only its documented HEXOS commands; it does not pass input to the host command processor.

Boot initializes and validates the ROM/RAM map, resets the virtual CPU, and selects reset PC `0000`. User program `.hex` files are fully validated before loading into simulated RAM at CPU word address `0100`; the maximum is `4000` words. `RUN` stops on HALT, reports invalid-instruction and memory faults, or stops at the instruction limit (default `10000`). `STEP` executes one instruction. `RESET` clears CPU and RAM and returns PC to `0000`; it does not erase or modify ROM.

Commands are `HELP`, `REG`, `MEM <address> [count]`, `LOAD <file.hex>`, `RUN`, `STEP`, `RESET`, and `EXIT`. Numbers in commands are hexadecimal by default; use `D:<digits>` for decimal (for example `MEM D:256`). Program images contain one four-digit hexadecimal word per line and may use `#` comments. They are data for the virtual CPU, never Python or host shell commands.

## Graphical desktop

Install the optional GUI dependency with `python -m pip install -e ".[gui]"` (or install PySide6 directly with `python -m pip install "PySide6>=6.6"`). Launch from PowerShell in the project directory with:

```powershell
$env:PYTHONPATH = 'src'
python -m hexos16.gui
```

The desktop includes CPU, memory, assembly, and console views. Edit assembly and choose **Assemble** to see the machine words; **Run** or **Step** assembles changed editor contents and executes them through the existing kernel and CPU. **Load .hex** selects a machine-word file and passes it through the kernel validator. Use **Reset** to clear simulated RAM and CPU state. Memory addresses and words are shown in hexadecimal; the memory selector keeps ROM (`0000–00FF`) distinct from RAM (`0100–10FF`). Run is on a worker thread, obeys the selected instruction limit, and can be stopped. Other state-changing controls are disabled while it runs. The console accepts only the documented HEXOS shell commands.

This is a Windows-hosted virtual machine application, not a native Windows or Android operating system. The host processor executes its ordinary native instructions; HEXOS hexadecimal formatting does not inherently increase speed or reduce physical memory use. No phone or firmware changes are made.
