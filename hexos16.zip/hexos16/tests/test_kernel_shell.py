import os
import tempfile
import unittest

from hexos16 import Kernel, KernelError, Shell


PROGRAM = """LDI R1, 2
LDI R2, 3
ADD R3, R1, R2
LDI16 R4, 0x0100
ST R3, R4
LD R5, R4
HALT
"""


class KernelTests(unittest.TestCase):
    def test_initialize_reset_and_load_validation(self):
        kernel = Kernel()
        self.assertEqual(kernel.cpu.pc, Kernel.ROM_RESET)
        self.assertTrue(kernel.initialized)
        kernel.ram.write(0, 0xFFFF)
        self.assertIn("RAM cleared", kernel.reset())
        self.assertEqual(kernel.ram.read(0), 0)
        before = kernel.ram.read(0)
        for content in ("", "GGGG", "10000", "123", "D000\n" * 4097):
            with self.subTest(content=content[:10]), self.assertRaises(KernelError):
                kernel.load_words(Kernel.parse_hex_image(content))
            self.assertEqual(kernel.ram.read(0), before)

    def test_loader_and_run_to_halt(self):
        kernel = Kernel()
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "program.hex")
            from hexos16 import assemble, format_hex
            with open(path, "w", encoding="ascii") as file:
                file.write(format_hex(assemble(PROGRAM)))
            self.assertIn("loaded", kernel.load_file(path))
        self.assertEqual(kernel.cpu.pc, 0x0100)
        self.assertIn("halted", kernel.run())
        self.assertEqual(kernel.ram.read(0), 5)
        self.assertEqual(kernel.cpu.registers[5], 5)

    def test_invalid_file_and_wrong_extension(self):
        kernel = Kernel()
        with tempfile.TemporaryDirectory() as folder:
            bad = os.path.join(folder, "bad.hex")
            with open(bad, "w", encoding="ascii") as file: file.write("12GG\n")
            with self.assertRaises(KernelError): kernel.load_file(bad)
            other = os.path.join(folder, "bad.txt")
            with open(other, "w", encoding="ascii") as file: file.write("D000\n")
            with self.assertRaises(KernelError): kernel.load_file(other)

    def test_limit_and_cpu_memory_faults(self):
        from hexos16 import assemble
        kernel = Kernel(instruction_limit=3)
        kernel.load_words(assemble("again: NOP\nBR again"))
        with self.assertRaisesRegex(KernelError, "instruction limit"):
            kernel.run()
        kernel.load_words([0x0101])
        with self.assertRaisesRegex(KernelError, "InvalidInstruction"):
            kernel.step()
        kernel.load_words([0xE120])
        kernel.cpu.registers[2] = 0x1100
        with self.assertRaisesRegex(KernelError, "IndexError"):
            kernel.step()


class ShellTests(unittest.TestCase):
    def test_commands_and_arguments(self):
        shell = Shell(Kernel())
        self.assertIn("MEM", shell.execute("HELP"))
        self.assertIn("PC=0000", shell.execute("REG"))
        self.assertEqual(shell.execute("MEM 0"), "0000: 0000")
        self.assertIn("malformed arguments", shell.execute("MEM"))
        self.assertIn("invalid number", shell.execute("MEM xyz"))
        self.assertIn("unknown command", shell.execute("Get-Process"))
        self.assertTrue(shell.running)
        self.assertEqual(shell.execute("EXIT"), "exit")
        self.assertFalse(shell.running)

    def test_load_step_run_reset(self):
        shell = Shell(Kernel())
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "sample.hex")
            from hexos16 import assemble, format_hex
            with open(path, "w", encoding="ascii") as file: file.write(format_hex(assemble(PROGRAM)))
            self.assertIn("loaded", shell.execute(f'LOAD "{path}"'))
        self.assertIn("PC=0101", shell.execute("STEP"))
        self.assertIn("halted", shell.execute("RUN"))
        self.assertEqual(shell.kernel.ram.read(0), 5)
        self.assertIn("RAM cleared", shell.execute("RESET"))
        self.assertEqual(shell.kernel.ram.read(0), 0)


if __name__ == "__main__": unittest.main()
