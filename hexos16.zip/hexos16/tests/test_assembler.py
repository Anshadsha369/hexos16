import unittest

from hexos16 import (AssemblyError, CPU, MemoryBus, RAM, ROM, assemble,
                     disassemble, format_hex)


class AssemblerTests(unittest.TestCase):
    def test_encodings_labels_and_hex_format(self):
        words = assemble("""start: LDI R1, 0xF
LDI RF, 15
ADD R2, R1, RF
BZ done
BR start
done: HALT
LD R3, R4
ST R3, R4
""")
        self.assertEqual(words, [0x110F, 0x1F0F, 0x321F, 0xA001, 0x90FB, 0xD000, 0xE340, 0xF340])
        self.assertEqual(format_hex(words), "110F\n1F0F\n321F\nA001\n90FB\nD000\nE340\nF340\n")

    def test_diagnostics(self):
        for source in ("BOGUS", "LDI R1, 16", "LDI R1, nope", "MOV RZ, R1", "BR missing", "HALT R1", "BR 200"):
            with self.subTest(source=source), self.assertRaises(AssemblyError): assemble(source)


class DisassemblerTests(unittest.TestCase):
    def test_decode_invalid_and_round_trip(self):
        source = "LDI R1, 2\nLDI R2, 3\nADD R3, R1, R2\nST R3, R4\nLD R5, R4\nHALT"
        words = assemble(source)
        listing = disassemble(words)
        canonical = [line.split(": ", 1)[1] for line in listing]
        self.assertEqual(assemble("\n".join(canonical)), words)
        self.assertEqual(disassemble([0xE341, 0xE000])[0], "0000: .WORD 0xE341")
        self.assertEqual(disassemble([0xE000])[0], "0000: LD R0, R0")
        full_word_words = assemble("LDI16 R4, 0x0100\nHALT")
        lines = disassemble(full_word_words)
        self.assertEqual(lines, ["0000: LDI16 R4, 0x0100", "0001: .DATA 0x0100", "0002: HALT"])

    def test_full_program_add_store_load(self):
        with open("examples/store_load.asm", encoding="utf-8") as source_file:
            words = assemble(source_file.read())
        bus = MemoryBus(ROM(words), RAM())
        cpu = CPU(memory=bus)
        steps = 0
        while not cpu.halted:
            cpu.step()
            steps += 1
        self.assertEqual(steps, 7)
        self.assertEqual(cpu.registers[3], 5)
        self.assertEqual(cpu.registers[5], 5)
        self.assertEqual(bus.ram.read(0), 5)


class MemoryInstructionTests(unittest.TestCase):
    def test_load_store_and_faults(self):
        bus = MemoryBus(ROM([0xE120, 0xF120, 0xD000]), RAM([0x4567]))
        cpu = CPU(memory=bus)
        cpu.registers[2] = 0x0100
        cpu.step()
        self.assertEqual(cpu.registers[1], 0x4567)
        cpu.registers[1] = 0xABCD
        cpu.step()
        self.assertEqual(bus.ram.read(0), 0xABCD)
        for address, instruction, exception in ((0, 0xF120, PermissionError), (0x1100, 0xE120, IndexError)):
            test_bus = MemoryBus(ROM([instruction]), RAM())
            test_cpu = CPU(memory=test_bus)
            test_cpu.registers[2] = address
            with self.assertRaises(exception): test_cpu.step()
            self.assertTrue(test_cpu.halted)
            self.assertIsInstance(test_cpu.error, exception)


if __name__ == "__main__": unittest.main()
