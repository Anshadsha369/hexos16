"""Stage A hardening regression tests.

These tests verify boundary conditions, security properties, and
architectural consistency across CPU, memory, assembler, and
kernel/shell components.  They never delete or weaken existing tests.
"""

import os
import tempfile
import unittest

from hexos16 import (
    CPU, Flags, InvalidInstruction,
    MemoryBus, RAM, ROM,
    AssemblyError, assemble, format_hex, disassemble,
    Kernel, KernelError, Shell,
)

MASK = 0xFFFF


# ---------------------------------------------------------------------------
# CPU hardening
# ---------------------------------------------------------------------------

class CPURegisterWidthTests(unittest.TestCase):
    """All register writes must be clamped to 16 bits via the ISA."""

    def _cpu_with(self, *words):
        return CPU(list(words))

    def test_ldi_max_nibble(self):
        cpu = self._cpu_with(0x110F)  # LDI R1, 15
        cpu.step()
        self.assertEqual(cpu.registers[1], 15)

    def test_ldi16_full_range(self):
        # LDI16 Rd, 0xFFFF
        cpu = self._cpu_with(0x0010 | (3 << 8), 0xFFFF)
        cpu.step()
        self.assertEqual(cpu.registers[3], 0xFFFF)

    def test_ldi16_zero(self):
        cpu = self._cpu_with(0x0010 | (5 << 8), 0x0000)
        cpu.step()
        self.assertEqual(cpu.registers[5], 0x0000)
        self.assertTrue(cpu.flags.z)

    def test_add_wraps_modulo_65536(self):
        cpu = CPU([0x3312])  # ADD R3, R1, R2
        cpu.registers[1] = 0xFFFF
        cpu.registers[2] = 0x0002
        cpu.step()
        self.assertEqual(cpu.registers[3], 0x0001)
        self.assertTrue(cpu.flags.c)
        self.assertFalse(cpu.flags.z)

    def test_sub_wraps_modulo_65536(self):
        cpu = CPU([0x4312])  # SUB R3, R1, R2
        cpu.registers[1] = 0x0000
        cpu.registers[2] = 0x0001
        cpu.step()
        self.assertEqual(cpu.registers[3], 0xFFFF)
        self.assertTrue(cpu.flags.n)
        self.assertFalse(cpu.flags.c)  # borrow occurred → C=0

    def test_and_result_width(self):
        cpu = CPU([0x5312])  # AND R3, R1, R2
        cpu.registers[1] = 0xFFFF
        cpu.registers[2] = 0xA5A5
        cpu.step()
        self.assertEqual(cpu.registers[3], 0xA5A5)
        self.assertFalse(cpu.flags.c)
        self.assertFalse(cpu.flags.v)

    def test_or_sets_n_flag(self):
        cpu = CPU([0x6312])  # OR R3, R1, R2
        cpu.registers[1] = 0x8000
        cpu.registers[2] = 0x0001
        cpu.step()
        self.assertEqual(cpu.registers[3], 0x8001)
        self.assertTrue(cpu.flags.n)

    def test_xor_same_registers_gives_zero(self):
        cpu = CPU([0x7111])  # XOR R1, R1, R1
        cpu.registers[1] = 0xABCD
        cpu.step()
        self.assertEqual(cpu.registers[1], 0x0000)
        self.assertTrue(cpu.flags.z)

    def test_pc_wraps_at_16_bits(self):
        # Place a branch at address FFFF that jumps by -1 (back to FFFF).
        flat = [0] * 0x10000
        flat[0xFFFF] = 0x90FF  # BR -1 (displacement = FF = -1 signed)
        cpu = CPU(memory=flat)
        cpu.pc = 0xFFFF
        cpu.step()
        # After fetch PC = 0x0000 (wraps), displacement = -1 → PC = 0xFFFF
        self.assertEqual(cpu.pc, 0xFFFF)

    def test_sp_initial_zero(self):
        cpu = CPU()
        self.assertEqual(cpu.sp, 0)
        cpu.reset()
        self.assertEqual(cpu.sp, 0)

    def test_reset_clears_error_and_unhalt(self):
        cpu = CPU([0x0101])  # invalid
        with self.assertRaises(InvalidInstruction):
            cpu.step()
        self.assertTrue(cpu.halted)
        self.assertIsNotNone(cpu.error)
        cpu.reset()
        self.assertFalse(cpu.halted)
        self.assertIsNone(cpu.error)

    def test_step_on_halted_returns_false_no_side_effects(self):
        cpu = CPU([0xD000, 0x1101])  # HALT, LDI R1, 1
        cpu.step()  # executes HALT
        self.assertTrue(cpu.halted)
        self.assertEqual(cpu.pc, 1)
        result = cpu.step()
        self.assertFalse(result)
        self.assertEqual(cpu.pc, 1)           # PC unchanged
        self.assertEqual(cpu.registers[1], 0) # R1 unchanged

    def test_cmp_does_not_write_register(self):
        cpu = CPU([0x8012])  # CMP R1, R2
        cpu.registers[1] = 5
        cpu.registers[2] = 3
        cpu.step()
        # CMP encodes d=0 per ISA; register 0 must not be written
        # The test checks flags and that R0 is still 0.
        self.assertEqual(cpu.registers[0], 0)
        self.assertTrue(cpu.flags.c)   # 5 >= 3

    def test_flags_preserved_by_nop(self):
        # LDI R1,2; LDI R2,1; CMP R1,R2 → R1=2 >= R2=1 → C=True; NOP preserves
        cpu = CPU([0x1102, 0x1201, 0x8012, 0x0000])
        for _ in range(4):
            cpu.step()
        # After NOP the flags from CMP must remain unchanged.
        self.assertTrue(cpu.flags.c)

    def test_instruction_count_deterministic(self):
        """Stepping N instructions from a known program produces a known PC."""
        words = assemble("LDI R0, 1\nLDI R1, 2\nADD R2, R0, R1\nHALT")
        cpu = CPU(words)
        count = 0
        while not cpu.halted:
            cpu.step()
            count += 1
        self.assertEqual(count, 4)
        self.assertEqual(cpu.registers[2], 3)


class CPUInvalidEncodingTests(unittest.TestCase):
    """Invalid opcodes and reserved fields must produce controlled faults."""

    def _expect_fault(self, word):
        cpu = CPU([word])
        with self.assertRaises(InvalidInstruction):
            cpu.step()
        self.assertTrue(cpu.halted)
        self.assertIsInstance(cpu.error, InvalidInstruction)

    def test_opcode0_nonzero_non_ldi16(self):
        self._expect_fault(0x0001)
        self._expect_fault(0x00F0)
        self._expect_fault(0x0100)

    def test_mov_reserved_b_nonzero(self):
        self._expect_fault(0x2141)

    def test_cmp_reserved_d_nonzero(self):
        self._expect_fault(0x8100)

    def test_branch_reserved_d_nonzero(self):
        self._expect_fault(0x9100)  # BR with d != 0
        self._expect_fault(0xA200)
        self._expect_fault(0xB300)
        self._expect_fault(0xC400)

    def test_halt_nonzero_suffix(self):
        self._expect_fault(0xD001)
        self._expect_fault(0xD100)

    def test_ld_reserved_b_nonzero(self):
        self._expect_fault(0xE121)

    def test_st_reserved_b_nonzero(self):
        self._expect_fault(0xF121)


class CPUBranchRangeTests(unittest.TestCase):
    def test_branch_forward_and_back(self):
        # Program: NOP × 3, then BR −4 (would loop forever, only take once)
        nop = 0x0000
        br_minus4 = 0x90FC  # displacement = FC = -4 signed → PC relative
        words = [nop, nop, nop, br_minus4]
        cpu = CPU(words)
        for _ in range(3):
            cpu.step()  # three NOPs
        cpu.step()  # BR -4 from PC=4 → 4 + (-4) = 0
        self.assertEqual(cpu.pc, 0)

    def test_bz_taken_when_z_set(self):
        cpu = CPU([0x1100, 0xA001])  # LDI R1, 0; BZ +1
        cpu.step()  # LDI R1, 0 → Z=True
        cpu.step()  # BZ should take → PC = 3
        self.assertEqual(cpu.pc, 3)

    def test_bnz_not_taken_when_z_set(self):
        cpu = CPU([0x1100, 0xB001])  # LDI R1, 0; BNZ +1
        cpu.step()
        cpu.step()
        self.assertEqual(cpu.pc, 2)  # BNZ not taken, PC just advances normally

    def test_bc_taken_when_carry_set(self):
        # ADD 0xFFFF + 1 sets carry, then BC +0 (stay, loop once)
        cpu = CPU([
            0x0010 | (1 << 8), 0xFFFF,  # LDI16 R1, 0xFFFF
            0x1201,                      # LDI R2, 1
            0x3312,                      # ADD R3, R1, R2 → carry
            0xC000,                      # BC +0 (stays at same PC: PC=5 after fetch, disp=0 → stays)
        ])
        cpu.step()  # LDI16
        cpu.step()  # LDI
        cpu.step()  # ADD → carry
        cpu.step()  # BC +0 → PC stays at 5 (no infinite loop, just verifies take)
        self.assertEqual(cpu.pc, 5)
        self.assertTrue(cpu.flags.c)


# ---------------------------------------------------------------------------
# Memory hardening
# ---------------------------------------------------------------------------

class MemoryBusHardeningTests(unittest.TestCase):
    def test_unmapped_read_raises(self):
        bus = MemoryBus()
        for addr in (0x1100, 0x1101, 0xFFFF, 0x10FF + 1):
            with self.subTest(addr=addr):
                with self.assertRaises(IndexError):
                    bus.read(addr)

    def test_unmapped_write_raises(self):
        bus = MemoryBus()
        for addr in (0x1100, 0xFFFF):
            with self.subTest(addr=addr):
                with self.assertRaises(IndexError):
                    bus.write(addr, 0)

    def test_rom_write_raises_permission(self):
        bus = MemoryBus()
        with self.assertRaises(PermissionError):
            bus.write(0x0000, 0x1234)
        with self.assertRaises(PermissionError):
            bus.write(0x00FF, 0x1234)

    def test_rom_boundaries_exact(self):
        rom = ROM([0xABCD])
        bus = MemoryBus(rom=rom)
        self.assertEqual(bus.read(0x0000), 0xABCD)
        self.assertEqual(bus.read(0x00FF), 0x0000)  # zero-padded

    def test_ram_boundaries_exact(self):
        bus = MemoryBus()
        bus.write(0x0100, 0x1111)
        self.assertEqual(bus.read(0x0100), 0x1111)
        bus.write(0x10FF, 0x9999)
        self.assertEqual(bus.read(0x10FF), 0x9999)

    def test_word_width_enforced_by_ram(self):
        bus = MemoryBus()
        for bad in (-1, 0x10000, 1.5, True):
            with self.subTest(bad=bad):
                with self.assertRaises((ValueError, TypeError)):
                    bus.write(0x0100, bad)

    def test_rom_is_truly_readonly_after_construction(self):
        rom = ROM([0xDEAD])
        with self.assertRaises(PermissionError):
            rom.write(0, 0x1234)
        # Direct _words access is not a supported API; check via read only.
        self.assertEqual(rom.read(0), 0xDEAD)

    def test_ram_clear_zeroes_all(self):
        ram = RAM([0xFFFF] * 4)
        ram.clear()
        for i in range(4):
            self.assertEqual(ram.read(i), 0)

    def test_inspect_bounds_check(self):
        ram = RAM()
        with self.assertRaises(IndexError):
            ram.inspect(0xFFF, 2)  # extends past end
        with self.assertRaises(IndexError):
            ram.inspect(0x1000, 1)  # start out of range

    def test_rom_inspect_bounds_check(self):
        rom = ROM()
        with self.assertRaises(IndexError):
            rom.inspect(0xFF, 2)
        with self.assertRaises(IndexError):
            rom.inspect(0x100, 1)


# ---------------------------------------------------------------------------
# Assembler hardening
# ---------------------------------------------------------------------------

class AssemblerHardeningTests(unittest.TestCase):
    def test_ldi16_extension_word_in_output(self):
        words = assemble("LDI16 R3, 0x1234")
        self.assertEqual(len(words), 2)
        self.assertEqual(words[0] & 0xF0FF, 0x0010)  # opcode structure
        self.assertEqual((words[0] >> 8) & 0xF, 3)   # dest = R3
        self.assertEqual(words[1], 0x1234)

    def test_ldi_immediate_range(self):
        # 0 and 15 are in range
        words = assemble("LDI R0, 0\nLDI RF, 15")
        self.assertEqual(words, [0x1000, 0x1F0F])
        # 16 is out of range
        with self.assertRaises(AssemblyError):
            assemble("LDI R0, 16")

    def test_branch_displacement_limits(self):
        # -128 is the minimum
        src = "start: NOP\n" + "NOP\n" * 126 + "BR start"
        words = assemble(src)
        br = words[-1]
        disp = br & 0xFF
        if disp & 0x80:
            disp -= 0x100
        self.assertEqual(disp, -128)
        # -129 is out of range
        with self.assertRaises(AssemblyError):
            assemble("start: NOP\n" + "NOP\n" * 128 + "BR start")
        # +127 is the maximum forward displacement
        src_fwd = "BR end\n" + "NOP\n" * 127 + "end: HALT"
        words_fwd = assemble(src_fwd)
        br_fwd = words_fwd[0] & 0xFF
        self.assertEqual(br_fwd, 127)

    def test_duplicate_label_rejected(self):
        with self.assertRaises(AssemblyError):
            assemble("start: NOP\nstart: NOP")

    def test_label_invalid_chars_rejected(self):
        with self.assertRaises(AssemblyError):
            assemble("1invalid: NOP")

    def test_unknown_mnemonic(self):
        with self.assertRaises(AssemblyError):
            assemble("PUSHF R1")

    def test_wrong_operand_count(self):
        with self.assertRaises(AssemblyError):
            assemble("ADD R1, R2")  # needs 3 operands

    def test_format_hex_deterministic(self):
        words = [0x0000, 0xABCD, 0x1F0F]
        out = format_hex(words)
        self.assertEqual(out, "0000\nABCD\n1F0F\n")

    def test_format_hex_rejects_invalid(self):
        with self.assertRaises(ValueError):
            format_hex([0x10000])
        with self.assertRaises(ValueError):
            format_hex([-1])
        with self.assertRaises(ValueError):
            format_hex([True])


class DisassemblerHardeningTests(unittest.TestCase):
    def test_nop_round_trips(self):
        words = assemble("NOP")
        self.assertEqual(words, [0x0000])
        listing = disassemble(words)
        self.assertEqual(listing[0], "0000: NOP")

    def test_ldi16_requires_following_word(self):
        # Without a following word, output is .WORD
        lines = disassemble([0x0310])  # LDI16 R3 header but no data word
        self.assertIn(".WORD", lines[0])

    def test_invalid_words_produce_dot_word(self):
        for bad in (0x2141, 0x8100, 0xD001):
            lines = disassemble([bad])
            self.assertIn(".WORD", lines[0])

    def test_disassembly_address_offset(self):
        words = [0x1101, 0xD000]  # LDI R1, 1; HALT
        lines = disassemble(words, start=0x0100)
        self.assertTrue(lines[0].startswith("0100:"))
        self.assertTrue(lines[1].startswith("0101:"))

    def test_empty_input_gives_empty_output(self):
        self.assertEqual(disassemble([]), [])


# ---------------------------------------------------------------------------
# Kernel hardening
# ---------------------------------------------------------------------------

class KernelHardeningTests(unittest.TestCase):
    def _make_kernel(self):
        return Kernel()

    def test_partial_load_does_not_corrupt_on_validation_failure(self):
        kernel = self._make_kernel()
        # Pre-fill RAM slot 0 with a known value
        kernel.ram.write(0, 0x1234)
        # An image with an invalid token after valid words
        bad_image = "D000\nGGGG\n"
        with self.assertRaises(KernelError):
            kernel.load_words(Kernel.parse_hex_image(bad_image))
        # Because parse_hex_image fails before load_words touches RAM,
        # the original value must be preserved.
        # (In reality parse_hex_image raises before load_words runs.)
        # Depending on whether we catch in parse or load, RAM may or may not
        # have changed; what we test is that kernel.ram still contains safe
        # data and is not left in a half-written corrupted state with 0.
        # We verify that the kernel remains usable after the failure.
        kernel2 = self._make_kernel()
        words = assemble("LDI R0, 7\nHALT")
        msg = kernel2.load_words(words)
        self.assertIn("loaded", msg)

    def test_oversized_program_rejected(self):
        kernel = self._make_kernel()
        # 4097 words exceeds the 4096-word RAM
        big = "D000\n" * 4097
        with self.assertRaises(KernelError):
            Kernel.parse_hex_image(big)

    def test_empty_program_rejected(self):
        kernel = self._make_kernel()
        with self.assertRaises(KernelError):
            Kernel.parse_hex_image("")
        with self.assertRaises(KernelError):
            Kernel.parse_hex_image("# only a comment\n")

    def test_non_hex_program_rejected(self):
        kernel = self._make_kernel()
        for bad in ("GGGG\n", "12GG\n", "123\n", "12345\n"):
            with self.subTest(bad=bad):
                with self.assertRaises(KernelError):
                    Kernel.parse_hex_image(bad)

    def test_load_does_not_write_to_rom(self):
        rom = ROM([0xDEAD])
        kernel = Kernel(rom=rom)
        kernel.load_words(assemble("HALT"))
        # ROM must still hold original value
        self.assertEqual(kernel.rom.read(0), 0xDEAD)

    def test_reset_clears_ram_not_rom(self):
        rom = ROM([0xDEAD])
        kernel = Kernel(rom=rom)
        kernel.load_words(assemble("LDI R0, 1\nHALT"))
        kernel.run()
        kernel.reset()
        self.assertEqual(kernel.rom.read(0), 0xDEAD)  # ROM unchanged
        self.assertEqual(kernel.ram.read(0), 0x0000)  # RAM cleared
        self.assertEqual(kernel.cpu.pc, 0x0000)

    def test_step_without_loaded_program_raises(self):
        kernel = self._make_kernel()
        with self.assertRaises(KernelError):
            kernel.step()

    def test_run_without_loaded_program_raises(self):
        kernel = self._make_kernel()
        with self.assertRaises(KernelError):
            kernel.run()

    def test_run_stops_on_halt(self):
        kernel = self._make_kernel()
        kernel.load_words(assemble("LDI R0, 5\nHALT"))
        result = kernel.run()
        self.assertIn("halted", result)
        self.assertEqual(kernel.cpu.registers[0], 5)

    def test_run_stops_at_instruction_limit(self):
        kernel = Kernel(instruction_limit=3)
        kernel.load_words(assemble("loop: BR loop"))
        with self.assertRaisesRegex(KernelError, "instruction limit"):
            kernel.run()

    def test_cpu_fault_propagates_as_kernel_error(self):
        kernel = self._make_kernel()
        kernel.load_words([0x0101])  # invalid encoding
        with self.assertRaisesRegex(KernelError, "InvalidInstruction"):
            kernel.step()

    def test_memory_fault_propagates_as_kernel_error(self):
        kernel = self._make_kernel()
        kernel.load_words([0xE120])  # LD R1, R2 — R2 = 0 (unmapped for RAM start)
        kernel.cpu.registers[2] = 0x1100  # unmapped address
        with self.assertRaisesRegex(KernelError, "IndexError"):
            kernel.step()

    def test_only_hex_extension_accepted(self):
        with tempfile.TemporaryDirectory() as folder:
            txt_file = os.path.join(folder, "prog.txt")
            with open(txt_file, "w") as f:
                f.write("D000\n")
            kernel = self._make_kernel()
            with self.assertRaises(KernelError):
                kernel.load_file(txt_file)

    def test_program_starts_at_0x0100(self):
        kernel = self._make_kernel()
        kernel.load_words(assemble("HALT"))
        self.assertEqual(kernel.cpu.pc, 0x0100)

    def test_inspect_rom_and_ram_addresses(self):
        kernel = self._make_kernel()
        rows = kernel.inspect(0x0000, 1)
        self.assertEqual(rows[0][0], "0000")
        kernel.load_words(assemble("HALT"))
        rows = kernel.inspect(0x0100, 1)
        self.assertEqual(rows[0][0], "0100")

    def test_inspect_unmapped_raises(self):
        kernel = self._make_kernel()
        with self.assertRaises(IndexError):
            kernel.inspect(0x1100, 1)

    def test_instruction_limit_must_be_positive(self):
        with self.assertRaises(ValueError):
            Kernel(instruction_limit=0)
        with self.assertRaises(ValueError):
            Kernel(instruction_limit=-1)


# ---------------------------------------------------------------------------
# Shell hardening
# ---------------------------------------------------------------------------

class ShellHardeningTests(unittest.TestCase):
    def _shell(self):
        return Shell(Kernel())

    def test_unknown_command_returns_error(self):
        shell = self._shell()
        result = shell.execute("Get-Process")
        self.assertIn("ERROR", result)
        self.assertIn("unknown command", result.lower())

    def test_host_command_not_executed(self):
        shell = self._shell()
        for hostile in ("Get-Process", "dir", "ls", "cat /etc/passwd", "python -c pass", "eval 1+1"):
            result = shell.execute(hostile)
            self.assertIn("ERROR", result)

    def test_empty_line_returns_empty_string(self):
        shell = self._shell()
        self.assertEqual(shell.execute(""), "")
        self.assertEqual(shell.execute("   "), "")

    def test_mem_count_bounds(self):
        shell = self._shell()
        self.assertIn("ERROR", shell.execute("MEM 0 0"))        # count < 1
        self.assertIn("ERROR", shell.execute("MEM 0 101"))      # count > 0x100

    def test_mem_invalid_address_hex(self):
        shell = self._shell()
        self.assertIn("ERROR", shell.execute("MEM xyz"))

    def test_mem_decimal_prefix(self):
        shell = self._shell()
        result = shell.execute("MEM D:0")
        self.assertNotIn("ERROR", result)
        self.assertIn("0000", result)

    def test_reg_shows_all_registers_and_flags(self):
        shell = self._shell()
        result = shell.execute("REG")
        for i in range(16):
            self.assertIn(f"R{i:X}=", result)
        self.assertIn("PC=", result)
        self.assertIn("SP=", result)
        self.assertIn("FLAGS=", result)

    def test_load_nonexistent_file_reports_error(self):
        shell = self._shell()
        result = shell.execute('LOAD "C:/does/not/exist.hex"')
        self.assertIn("ERROR", result)

    def test_exit_stops_loop(self):
        shell = self._shell()
        self.assertTrue(shell.running)
        shell.execute("EXIT")
        self.assertFalse(shell.running)

    def test_malformed_quoted_argument(self):
        shell = self._shell()
        result = shell.execute('LOAD "unterminated')
        self.assertIn("ERROR", result)

    def test_mem_unmapped_address_error(self):
        shell = self._shell()
        result = shell.execute("MEM 1100")
        self.assertIn("ERROR", result)

    def test_reset_resets_pc_to_zero(self):
        shell = self._shell()
        words = assemble("LDI R0, 1\nHALT")
        kernel = shell.kernel
        kernel.load_words(words)
        shell.execute("RUN")
        shell.execute("RESET")
        self.assertEqual(shell.kernel.cpu.pc, 0x0000)

    def test_step_reports_pc(self):
        shell = self._shell()
        kernel = shell.kernel
        kernel.load_words(assemble("LDI R0, 1\nHALT"))
        result = shell.execute("STEP")
        self.assertIn("PC=", result)

    def test_run_after_halt_resets_needed(self):
        """After program halts, run again should work after reset+reload."""
        shell = self._shell()
        kernel = shell.kernel
        kernel.load_words(assemble("HALT"))
        shell.execute("RUN")
        # CPU is halted; calling run again should re-execute (kernel.run restarts PC)
        # Actually the kernel.run() re-raises if halted; check that RESET+load works.
        shell.execute("RESET")
        kernel.load_words(assemble("HALT"))
        result = shell.execute("RUN")
        self.assertIn("halted", result)


# ---------------------------------------------------------------------------
# Kernel parse_hex_image vs _validate_contents consistency
# ---------------------------------------------------------------------------

class HexImageParserTests(unittest.TestCase):
    """Ensure parse_hex_image and _validate_contents behave consistently."""

    def test_comment_lines_are_ignored(self):
        image = "# This is a comment\nD000\n# another\n"
        words = Kernel.parse_hex_image(image)
        self.assertEqual(words, [0xD000])

    def test_blank_lines_are_ignored(self):
        image = "\n\nD000\n\n"
        words = Kernel.parse_hex_image(image)
        self.assertEqual(words, [0xD000])

    def test_lowercase_hex_accepted(self):
        words = Kernel.parse_hex_image("d000\n")
        self.assertEqual(words, [0xD000])

    def test_exactly_4096_words_accepted(self):
        image = "D000\n" * 4096
        words = Kernel.parse_hex_image(image)
        self.assertEqual(len(words), 4096)

    def test_4097_words_rejected(self):
        image = "D000\n" * 4097
        with self.assertRaises(KernelError):
            Kernel.parse_hex_image(image)


if __name__ == "__main__":
    unittest.main()
