import os
import tempfile
import time
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

try:
    from PySide6.QtWidgets import QApplication
    from hexos16.gui import MainWindow
except ImportError:
    QApplication = None
    MainWindow = None


@unittest.skipIf(QApplication is None, "PySide6 GUI extra is not installed")
class GUITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.window = MainWindow()
        self.window.show()
        self.app.processEvents()

    def tearDown(self):
        if self.window._worker:
            self.window.stop_program()
            if self.window._thread:
                self.window._thread.quit(); self.window._thread.wait(2000)
        self.window.close()
        self.app.processEvents()

    def test_window_cpu_memory_and_assembly_errors(self):
        self.assertEqual(self.window.kernel.cpu.pc, 0)
        self.window.kernel.cpu.registers[1] = 0xABCD
        self.window.refresh_cpu()
        self.assertEqual(self.window.register_table.item(0, 1).text(), "ABCD")
        self.window.mem_region.setCurrentIndex(1)
        self.window.mem_address.setText("0100")
        self.window.kernel.bus.write(0x100, 0x4321)
        self.window.refresh_memory()
        self.assertEqual(self.window.memory_table.item(0, 1).text(), "4321")
        self.window.editor.setPlainText("NOPE R1")
        self.assertFalse(self.window.assemble_source())
        self.assertIn("line 1", self.window.assembly_status.text())
        self.window.editor.setPlainText("LDI R1, 1\nHALT")
        self.assertTrue(self.window.assemble_source())
        self.assertIn("1101", self.window.machine_words.toPlainText())
        self.assertIn("LDI R1, 1", self.window.disassembly_view.toPlainText())

    def test_step_reset_run_limit_and_halt(self):
        self.window.editor.setPlainText("LDI R1, 7\nHALT")
        self.window.step_program()
        self.assertEqual(self.window.kernel.cpu.registers[1], 7)
        self.window.reset_machine()
        self.assertEqual(self.window.kernel.cpu.registers[1], 0)
        self.window.editor.setPlainText("again: NOP\nBR again")
        self.window.limit.setValue(5000)
        self.window.run_program()
        self.assertTrue(self.window._busy)
        self.window.reset_machine()
        self.assertTrue(self.window._busy)
        self.window.stop_program()
        deadline = time.time() + 5
        while self.window._busy and time.time() < deadline:
            self.app.processEvents(); time.sleep(0.01)
        self.assertFalse(self.window._busy)
        self.window.editor.setPlainText("LDI R1, 2\nHALT")
        self.window.limit.setValue(100)
        self.window.run_program()
        deadline = time.time() + 5
        while self.window._busy and time.time() < deadline:
            self.app.processEvents(); time.sleep(0.01)
        self.assertTrue(self.window.kernel.cpu.halted)
        self.assertEqual(self.window.kernel.cpu.registers[1], 2)
        self.assertEqual(self.window.kernel.instruction_count, 2)
        self.window.editor.setPlainText("again: NOP\nBR again")
        self.window.limit.setValue(5)
        self.window.run_program()
        deadline = time.time() + 5
        while self.window._busy and time.time() < deadline:
            self.app.processEvents(); time.sleep(0.01)
        self.assertFalse(self.window._busy)
        self.assertIn("Instruction limit 0005", self.window.console.toPlainText())

    def test_invalid_hex_load_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "bad.hex")
            with open(path, "w", encoding="ascii") as file:
                file.write("GGGG\n")
            self.assertFalse(self.window.load_hex(path))
            self.assertEqual(self.window.kernel.loaded_words, 0)


if __name__ == "__main__":
    unittest.main()
