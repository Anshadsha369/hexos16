import unittest

from hexos16 import CPU, InvalidInstruction


def rr(op, d, a, b): return (op << 12) | (d << 8) | (a << 4) | b
def imm(op, d, value): return (op << 12) | (d << 8) | value
def branch(op, displacement): return (op << 12) | (displacement & 0xFF)


class CPUTests(unittest.TestCase):
    def test_reset_and_width(self):
        cpu = CPU([imm(1, 0, 3)])
        cpu.registers[15] = 0x12345
        cpu.reset()
        self.assertEqual(cpu.registers, [0] * 16)
        self.assertEqual((cpu.pc, cpu.sp), (0, 0))
        self.assertEqual((cpu.flags.z, cpu.flags.n, cpu.flags.c, cpu.flags.v), (False,) * 4)
        cpu.load_program([imm(1, 15, 0xF)])
        cpu.step()
        self.assertEqual(cpu.registers[15], 15)

    def test_all_arithmetic_and_logic(self):
        cpu = CPU([imm(1, 1, 0xF), imm(1, 2, 1), rr(3, 3, 1, 2), rr(4, 4, 2, 1), rr(5, 5, 1, 2), rr(6, 6, 1, 2), rr(7, 7, 1, 2), rr(8, 0, 2, 1)])
        for _ in range(8): cpu.step()
        self.assertEqual(cpu.registers[3:8], [16, 0xFFF2, 1, 0xF, 0xE])
        self.assertTrue(cpu.flags.n)  # CMP 1 - 15 = FFF2
        self.assertFalse(cpu.flags.c)

    def test_add_carry_and_signed_overflow(self):
        cpu = CPU([rr(3, 3, 1, 2)])
        cpu.registers[1:3] = [0xFFFF, 1]
        cpu.step()
        self.assertEqual(cpu.registers[3], 0)
        self.assertTrue(cpu.flags.z and cpu.flags.c)
        self.assertFalse(cpu.flags.v)
        cpu.load_program([rr(3, 3, 1, 2)])
        cpu.registers[1:3] = [0x7FFF, 1]
        cpu.step()
        self.assertEqual(cpu.registers[3], 0x8000)
        self.assertTrue(cpu.flags.n and cpu.flags.v)
        self.assertFalse(cpu.flags.c)

    def test_subtract_and_compare_flags(self):
        cpu = CPU([rr(4, 3, 1, 2), rr(8, 0, 1, 2)])
        cpu.registers[1:3] = [0, 1]
        cpu.step()
        self.assertEqual(cpu.registers[3], 0xFFFF)
        self.assertTrue(cpu.flags.n)
        self.assertFalse(cpu.flags.c)
        cpu.step()
        self.assertEqual(cpu.registers[3], 0xFFFF)  # CMP does not write
        self.assertFalse(cpu.flags.c)

    def test_branch_conditions_and_pc(self):
        cpu = CPU([imm(1, 1, 0), imm(1, 2, 0), rr(8, 0, 1, 2), branch(10, 1), imm(1, 3, 1), branch(11, 1), imm(1, 3, 2), branch(12, 1), imm(1, 3, 3)])
        for _ in range(6): cpu.step()
        self.assertEqual(cpu.pc, 7)
        self.assertEqual(cpu.registers[3], 2)
        cpu.load_program([branch(9, 0xFE)])
        cpu.step()
        self.assertEqual(cpu.pc, 0xFFFF)

    def test_decode_invalid_and_deterministic_step(self):
        cpu = CPU([imm(1, 4, 0xA), rr(2, 5, 4, 0), 0x0101])
        self.assertTrue(cpu.step()); self.assertEqual((cpu.pc, cpu.registers[4]), (1, 10))
        self.assertTrue(cpu.step()); self.assertEqual((cpu.pc, cpu.registers[5]), (2, 10))
        with self.assertRaises(InvalidInstruction): cpu.step()
        self.assertTrue(cpu.halted)
        self.assertFalse(cpu.step())

    def test_halt_and_encoding_validation(self):
        for word in (0x0001, 0x2141, 0x8100, 0xD001):
            cpu = CPU([word])
            with self.assertRaises(InvalidInstruction): cpu.step()
            self.assertEqual(cpu.pc, 1)
        cpu = CPU([0xD000])
        self.assertTrue(cpu.step())
        self.assertTrue(cpu.halted)
        self.assertFalse(cpu.step())
        self.assertEqual(cpu.pc, 1)


if __name__ == "__main__": unittest.main()
