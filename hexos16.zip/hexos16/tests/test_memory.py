import unittest

from hexos16 import CPU, MemoryBus, RAM, ROM


class RAMTests(unittest.TestCase):
    def test_size_initialization_and_boundaries(self):
        ram = RAM()
        self.assertEqual(len(ram._words), 4096)
        self.assertEqual(ram.read(0), 0)
        self.assertEqual(ram.read(0xFFF), 0)
        ram.write(0, 0x1234)
        ram.write(0xFFF, 0xABCD)
        self.assertEqual(ram.inspect(0, 1), [("0000", "1234")])
        self.assertEqual(ram.inspect(0xFFF, 1), [("0FFF", "ABCD")])
        ram.clear()
        self.assertEqual(ram.read(0), 0)
        self.assertEqual(ram.read(0xFFF), 0)
        for addr in (-1, 0x1000):
            with self.assertRaises(IndexError): ram.read(addr)
            with self.assertRaises(IndexError): ram.write(addr, 1)
        with self.assertRaises(ValueError): RAM([0] * 4097)

    def test_reject_invalid_words(self):
        ram = RAM()
        for value in (-1, 0x10000, 1.5, True):
            with self.assertRaises(ValueError): ram.write(0, value)
        with self.assertRaises(ValueError): RAM([0, 0x10000])


class ROMTests(unittest.TestCase):
    def test_loading_short_image_and_boundaries(self):
        rom = ROM("1234\nABCD # comment\n")
        self.assertEqual(rom.read(0), 0x1234)
        self.assertEqual(rom.read(1), 0xABCD)
        self.assertEqual(rom.read(0xFF), 0)
        self.assertEqual(len(rom._words), 256)
        with self.assertRaises(IndexError): rom.read(-1)
        with self.assertRaises(IndexError): rom.read(0x100)
        with self.assertRaises(PermissionError): rom.write(0, 0)

    def test_reject_malformed_and_oversized_images(self):
        for image in ("12", "GGGG", "12345", [0x10000], [-1]):
            with self.assertRaises(ValueError): ROM(image)
        with self.assertRaises(ValueError): ROM([0] * 257)


class MemoryIntegrationTests(unittest.TestCase):
    def test_rom_fetch_and_ram_result(self):
        # LDI R1,2; LDI R2,3; ADD R3,R1,R2; then the program stores R3
        # through host setup to verify the bus RAM interface independently.
        rom = ROM([0x1102, 0x1203, 0x3312, 0xD000])
        bus = MemoryBus(rom=rom, ram=RAM())
        cpu = CPU(memory=bus)
        for _ in range(4): cpu.step()
        self.assertEqual(cpu.registers[3], 5)
        bus.write(MemoryBus.RAM_START, cpu.registers[3])
        self.assertEqual(bus.read(MemoryBus.RAM_START), 5)
        self.assertEqual(bus.read(0), 0x1102)
        with self.assertRaises(PermissionError): bus.write(0, 0xD000)


if __name__ == "__main__": unittest.main()
