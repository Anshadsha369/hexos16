# HEXOS-16 CPU ISA, milestones 1–3

All instructions are 16-bit words, displayed as four hexadecimal digits. The PC counts words. There is no implicit delay slot. An instruction fetch reads the word at PC and advances PC by one before execution; taken branches replace that advanced PC. Register encodings are hexadecimal nibbles (`0` = R0 through `F` = RF). R0 is a normal writable register.

## Encoding

Register format: `OOOO DDDD AAAA BBBB` (opcode, destination, source A, source B). Immediate format: `OOOO DDDD IIII` (`IIII` is an unsigned 4-bit immediate). Branch format: `OOOO CCCC displacement[7:0]`; bits 11–8 are reserved zero and the low byte is a signed two's-complement displacement in words relative to the already-advanced PC. There are no extension words: every implemented instruction is exactly one word.

| Opcode | Mnemonic | Encoding / operation |
|---|---|---|
| 0 | NOP / LDI16 | `0000 0000 0000 0000` is NOP; `0000 DDDD 0001 0000` followed by a 16-bit literal is LDI16 |
| 1 | LDI | `0001 DDDD IIII`; `R[D] = zero_extend(IIII)` |
| 2 | MOV | `0010 DDDD AAAA 0000`; `R[D] = R[A]` |
| 3 | ADD | `0011 DDDD AAAA BBBB`; `R[D] = R[A] + R[B]` |
| 4 | SUB | `0100 DDDD AAAA BBBB`; `R[D] = R[A] - R[B]` |
| 5 | AND | `0101 DDDD AAAA BBBB`; bitwise AND |
| 6 | OR | `0110 DDDD AAAA BBBB`; bitwise OR |
| 7 | XOR | `0111 DDDD AAAA BBBB`; bitwise XOR |
| 8 | CMP | `1000 0000 AAAA BBBB`; set flags as if `R[A]-R[B]`, no writeback |
| 9 | BR | `1001 0000 displacement[7:0]`; unconditional relative branch |
| A | BZ | `1010 0000 displacement[7:0]`; branch if Z=1 |
| B | BNZ | `1011 0000 displacement[7:0]`; branch if Z=0 |
| C | BC | `1100 0000 displacement[7:0]`; branch if C=1 |
| D | HALT | `1101 0000 0000 0000` only |
| E | LD | `1110 DDDD AAAA 0000`; `R[D] = memory[R[A]]` |
| F | ST | `1111 DDDD AAAA 0000`; `memory[R[A]] = R[D]` |

`LDI` remains the original one-word nibble load. To allow guest code to form RAM addresses, `LDI16` is a two-word instruction using reserved subencoding `0000` of opcode 0: first word `0000 0000 DDDD 0000`, second word the literal `IIIIIIIIIIIIIIII`. The literal is consumed as data and is not decoded as an instruction. PC advances by two words. The encoding `0000 0000 0000 0000` remains NOP; other opcode-0 words are invalid unless they match `LDI16` exactly. `LDI16` sets Z/N from the loaded value and clears C/V.

LD and ST use register-indirect **absolute CPU word addresses**. The address register must contain a mapped bus address: ROM `0000–00FF` or RAM `0100–10FF`. LD may read either region. ST is valid only for RAM; a ROM write raises `PermissionError`, and an unmapped address raises `IndexError`. Invalid opcode/encoding raises `InvalidInstruction`; execution faults are saved in `CPU.error`, halt the CPU, and are re-raised by the triggering `step()` call. PC is not changed by a data access.

Reserved fields must be zero; malformed encodings and opcodes E–F raise `InvalidInstruction` after the fetch has advanced PC. Execution errors are explicit exceptions and leave the machine halted with `error` set. `step()` on a halted or faulted CPU performs no fetch and returns `False`; a successful instruction returns `True` (including the instruction that halts).

## State and flags

Sixteen unsigned 16-bit general registers R0–RF; 16-bit PC and SP. Reset clears registers, PC, SP, and flags, and unhalts/clears error. Flags are Z (zero), N (result bit 15), C (unsigned carry for addition; no-borrow for subtraction/compare), and V (signed two's-complement overflow). LDI/MOV/logical operations set Z and N and clear C,V. ADD/SUB set all four. CMP sets all four from subtraction. Branches, NOP, and HALT preserve flags. Arithmetic wraps modulo 2^16.

## Byte order and image representation

Instructions are architecturally words; textual machine code uses four hex digits per word. When serializing words as bytes, the defined order is big-endian (most significant byte first). No binary image loader is part of this milestone.

## Milestone 2 memory map and CPU interface

The PC remains a 16-bit **word address**, not a byte address. The memory bus maps ROM at `0000–00FF` (256 words) and RAM at `0100–10FF` (4,096 words). The remaining addresses are unmapped and reads/writes raise explicit errors. There is no memory-mapped I/O. CPU instruction fetch and LD/ST data access use the supplied `read(address)`/`write(address, value)` interface. `CPU(program)` still supports legacy flat 65,536-word mode; E/F load/store instructions work there too, though that mode has no ROM protection. With `CPU(memory=MemoryBus(...))`, programs are preloaded in ROM and the CPU fetches them there. RAM/ROM words reject values outside `0000–FFFF`; RAM starts zeroed, and short ROM images are zero-filled to 256 words. ROM is read-only after construction.

## Assembler and disassembler

Assembly supports labels, registers `R0`–`RF`, and `0x`-prefixed hexadecimal literals; bare numeric literals are decimal. Branch operands are labels (resolved to signed 8-bit displacement from the next word) or signed decimal/hex displacements. `.hex` output is one four-digit word per line, uppercase, with a final newline and no addresses. Disassembly prints canonical mnemonic text and `.WORD 0xNNNN` for invalid/reserved encodings. It preserves the one-word instruction boundaries but is not a textual round-trip for labels, source formatting, or exact alias spelling; valid words can be reassembled to identical encodings.

## Kernel boot and shell (milestone 4)

The simulator constructs ROM/RAM, validates the fixed map, resets CPU state, and sets the ROM reset vector to `0000`. This milestone does not add a ROM boot instruction or syscall; machine startup is host-controlled by the kernel module. User `.hex` programs are validated completely (ASCII text, one four-digit word per noncomment line, 1–`4000` words) before writing to RAM. They begin at CPU word address `0100`; ROM remains read-only. `RUN` enforces a configurable positive instruction limit and stops at HALT or reports a CPU/memory fault. `RESET` clears CPU and RAM state and returns PC to `0000`. No machine-code file executes host code.

The restricted text shell recognizes only HELP, REG, MEM, LOAD, RUN, STEP, RESET, and EXIT. It never invokes a host shell. Shell numeric arguments are hexadecimal by default; prefix with `0x` also works, and `D:<digits>` explicitly enters decimal (for example `MEM D:256`).

## Desktop UI (milestone 5)

The optional PySide6 application is a presentation and control layer over the same `Kernel`, `CPU`, `MemoryBus`, assembler, and shell APIs. Run executes on a worker thread while a shared lock serializes individual simulator operations; worker results are delivered to Qt widgets through queued signals. ROM remains protected by the bus. GUI file loading invokes `Kernel.load_file`, which validates `.hex` data before writing RAM. There is no native boot, host command execution, or separate UI-side CPU simulation.
