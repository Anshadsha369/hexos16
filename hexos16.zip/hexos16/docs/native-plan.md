# Native operating-system audit and implementation plan

## Milestone 0 audit (2026-10-24)

### Existing project

The repository is a Python 3.10+ package under `src/hexos16/`. The reference VM is split into CPU, memory, assembler, disassembler, kernel, and restricted shell modules. The optional PySide6 GUI lives in `src/hexos16/gui/`. Tests cover CPU/ISA behavior, memory, kernel shell, assembler, hardening, and GUI. The ISA contract is in `docs/isa.md`; it defines a 16-bit word-addressed guest with 16 registers, PC/SP, flags, memory operations, and `LDI16`.

Current tests on Python 3.13.14: **109 passed, 3 skipped, 26 subtests passed** (`python -m pytest -q`). The three skips are existing skips; none were changed. The project root is not currently a Git repository (`git status` reports “not a git repository”), so there was no tracked/untracked change list to inspect.

### Toolchain inventory

Windows `PATH` and PowerShell command discovery found no Clang, GCC, AArch64 cross-compiler, LLD, LLVM objcopy, QEMU AArch64 system emulator, GDB, or Make. WSL is present, but the only registered distribution is `docker-desktop`, a managed Docker distribution rather than a development distro. A probe there produced only WSL path-translation warnings and no available compiler/emulator commands. No native build or emulator boot can currently be run.

### Proposed first native target

Target A remains **AArch64 on QEMU `virt`**, using freestanding C11 and a small AArch64 entry stub, with a serial console. The actual QEMU boot protocol and image format must be established with the installed QEMU version before selecting linker addresses or emitting an image. The initial candidate to evaluate is QEMU's documented AArch64 `virt` direct-kernel boot path; do not assume a generic ELF or raw image is accepted. The emulator is currently unavailable, so this target and its entry convention remain proposed, not verified.

### Milestone 1 design

Keep native code under `native/`, separate from the Python reference. The first coherent implementation should add only:

- `native/arch/aarch64/start.S`: entry symbol, stack setup/alignment, and transfer to C.
- `native/kernel/main.c`: serial-visible staged startup, then a safe idle loop.
- `native/drivers/uart_pl011.c` and a small header: QEMU `virt` PL011 serial output, using the documented platform map.
- `native/linker/aarch64-virt.ld`: entry and section layout only after boot protocol/load address are verified.
- `native/Makefile`: explicit cross-compiler, linker, image, inspect, run, and clean targets with tool checks.
- `native/README.md` and `docs/boot.md`: exact boot protocol, prerequisites, build command, and captured boot evidence.

Planned dependencies: first choose and verify the toolchain/QEMU versions and boot protocol; then implement the startup and UART; then inspect the ELF/image; finally capture QEMU serial output with a timeout. Do not print memory/interrupt/HEXVM success markers until those subsystems exist and initialize successfully.

### Blockers and first implementation steps

1. Install a supported developer Linux distribution in WSL2 (for example Ubuntu), then install a documented AArch64 cross compiler/binutils, QEMU system AArch64, Make, and GDB (or GDB multiarch). Alternatively install equivalent native Windows toolchain components.
2. Record exact versions and confirm commands resolve in the same environment.
3. Verify that the installed QEMU accepts the selected AArch64 `virt` boot method and determine its entry/load contract from its documentation and a minimal experiment.
4. Add the minimal startup, linker, UART, C kernel, and reproducible build target; inspect the generated ELF and run it under QEMU.
5. Rerun the Python suite unchanged as a regression check.

No native source has been added yet because without the compiler, emulator, and verified entry protocol, a linker address or claimed bootable image would be guesswork. The existing Python implementation remains untouched. The OPPO F3 CPH1609 is not assessed by this milestone; QEMU compatibility would not establish phone compatibility.
